import { useEffect, useRef, useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { BRAND_ASSETS } from '../data/agencyData';

export type AppRoute = '/' | '/services' | '/portfolio' | '/about' | '/contact';

interface NavbarProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
}

const NAV_ITEMS: { label: string; route: AppRoute }[] = [
  { label: 'Home', route: '/' },
  { label: 'Services', route: '/services' },
  { label: 'Portfolio', route: '/portfolio' },
  { label: 'About', route: '/about' },
  { label: 'Contact', route: '/contact' },
];

export function Navbar({ currentRoute, onNavigate }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const progressRef = useRef<HTMLDivElement>(null);
  const scrolledRef = useRef(false);

  useEffect(() => {
    let rafId = 0;
    const updateScroll = () => {
      const scrollY = window.scrollY;
      const isNowScrolled = scrollY > 24;
      if (isNowScrolled !== scrolledRef.current) {
        scrolledRef.current = isNowScrolled;
        setScrolled(isNowScrolled);
      }
      const maxScroll = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight
      );
      const ratio = Math.min(1, Math.max(0, scrollY / maxScroll));
      if (progressRef.current) {
        progressRef.current.style.transform = `scaleX(${ratio})`;
      }
    };

    const onScroll = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(updateScroll);
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    updateScroll();
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileOpen]);

  const handleLinkClick = (route: AppRoute) => {
    setMobileOpen(false);
    onNavigate(route);
  };

  return (
    <>
      {/* Razor-sharp top viewport scroll progress bar */}
      <div
        ref={progressRef}
        aria-hidden="true"
        className="fixed top-0 left-0 right-0 z-[60] h-[3px] origin-left scale-x-0 bg-gradient-to-r from-[#F5A623] via-[#FFD166] to-[#0D0E11]"
      />

      <header className="fixed top-3 sm:top-4 left-0 right-0 z-50 px-3 sm:px-6 lg:px-10 pointer-events-none">
        <div
          className={`pointer-events-auto mx-auto flex h-[72px] sm:h-[82px] max-w-[1340px] items-center justify-between gap-4 sm:gap-8 rounded-full px-4 sm:px-6 transition-all duration-300 backdrop-blur-2xl backdrop-saturate-150 ${
            scrolled
              ? 'bg-[#0D0E11]/88 border border-white/15 ring-1 ring-black/25 shadow-[0_20px_54px_-12px_rgba(13,14,17,0.45),inset_0_1px_0_rgba(255,255,255,0.18)]'
              : 'bg-[#0D0E11]/78 border border-white/15 ring-1 ring-black/20 shadow-[0_14px_40px_-10px_rgba(13,14,17,0.32),inset_0_1px_0_rgba(255,255,255,0.16)]'
          }`}
        >
          {/* Left Mobile Spacer to keep logo dead-center on mobile */}
          <div className="w-10 shrink-0 md:hidden" aria-hidden="true" />

          {/* Zone 1: Enlarged Logo Only (Centered on mobile, left-aligned on desktop) */}
          <button
            type="button"
            onClick={() => handleLinkClick('/')}
            className="group relative flex items-center justify-center md:justify-start shrink-0 py-1 transition-transform duration-300 hover:scale-105 cursor-pointer"
            aria-label="The XMarketeer Home"
          >
            <img
              src={BRAND_ASSETS.logoLight}
              alt="The XMarketeer"
              className="h-14 sm:h-[68px] w-auto object-contain object-center md:object-left scale-[1.12] origin-center md:origin-left drop-shadow-[0_2px_12px_rgba(245,166,35,0.22)]"
              referrerPolicy="no-referrer"
            />
          </button>

          {/* Zone 2: Gen-Z Glassy Nav Dock */}
          <nav
            className="hidden md:flex items-center gap-1 rounded-full border border-white/12 bg-white/[0.06] backdrop-blur-xl p-1 shadow-[inset_0_1px_2px_rgba(255,255,255,0.06)]"
            aria-label="Primary Navigation"
          >
            {NAV_ITEMS.map((item) => {
              const active = currentRoute === item.route;
              return (
                <button
                  key={item.route}
                  type="button"
                  onClick={() => handleLinkClick(item.route)}
                  className={`inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-sm font-medium whitespace-nowrap shrink-0 transition-all duration-200 cursor-pointer ${
                    active
                      ? 'bg-white text-[#0D0E11] shadow-[0_6px_16px_-4px_rgba(255,255,255,0.28)] font-semibold'
                      : 'text-white/75 hover:text-white hover:bg-white/[0.1]'
                  }`}
                >
                  {active && (
                    <span className="h-1.5 w-1.5 rounded-full bg-[#F5A623] animate-pulse" />
                  )}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Gen-Z Accent Action + Glass Mobile Menu Trigger */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => handleLinkClick('/contact')}
              className="hidden md:inline-flex items-center gap-1.5 rounded-full bg-[#F5A623] px-5 py-2.5 text-xs font-bold text-[#0D0E11] shadow-[0_6px_20px_-4px_rgba(245,166,35,0.55)] transition-all duration-200 hover:bg-white hover:text-[#0D0E11] hover:shadow-[0_8px_22px_-4px_rgba(255,255,255,0.3)] whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Start a Project</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>

            <button
              type="button"
              onClick={() => setMobileOpen((prev) => !prev)}
              aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileOpen}
              className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/10 text-white backdrop-blur-md transition-colors hover:border-[#F5A623] hover:text-[#F5A623] md:hidden cursor-pointer"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Glass Drawer */}
      <div
        className={`fixed inset-0 z-40 bg-[#0D0E11]/95 backdrop-blur-2xl text-white transition-all duration-300 md:hidden ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex h-full flex-col justify-between px-6 pt-28 pb-10">
          <nav className="flex flex-col gap-3" aria-label="Mobile Navigation">
            {NAV_ITEMS.map((item, idx) => {
              const active = currentRoute === item.route;
              return (
                <button
                  key={item.route}
                  type="button"
                  onClick={() => handleLinkClick(item.route)}
                  className={`flex items-center justify-between border-b border-white/10 py-4 text-left font-display text-3xl font-bold tracking-tight transition-colors cursor-pointer ${
                    active ? 'text-[#F5A623]' : 'text-white hover:text-[#F5A623]'
                  }`}
                >
                  <span>{item.label}</span>
                  <span className="font-mono text-xs text-white/45">0{idx + 1}</span>
                </button>
              );
            })}
          </nav>

          <div className="space-y-4">
            <button
              type="button"
              onClick={() => handleLinkClick('/contact')}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-[#F5A623] py-3.5 text-sm font-bold text-[#0D0E11] hover:bg-white transition-colors cursor-pointer"
            >
              <span>Start a Project</span>
              <ArrowUpRight className="h-4 w-4" />
            </button>
            <p className="text-center text-xs text-white/55">
              thexmarketeer@gmail.com · Karachi, Pakistan
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
