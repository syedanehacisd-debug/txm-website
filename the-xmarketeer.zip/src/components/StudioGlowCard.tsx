import { useEffect, useRef, type ReactNode } from 'react';
import gsap from 'gsap';

interface StudioGlowCardProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  cursorText?: string;
  tilt?: boolean;
  tiltStrength?: number;
  tone?: 'light' | 'dark';
}

export function StudioGlowCard({
  children,
  className = '',
  onClick,
  cursorText,
  tilt = false,
  tiltStrength = 6,
  tone = 'light',
}: StudioGlowCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const borderGlowRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const card = cardRef.current;
    const glow = glowRef.current;
    const borderGlow = borderGlowRef.current;
    if (!card || !glow || !borderGlow) return;

    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduceMotion) return;

    const gX = gsap.quickTo(glow, 'x', { duration: 0.35, ease: 'power2.out' });
    const gY = gsap.quickTo(glow, 'y', { duration: 0.35, ease: 'power2.out' });
    const bX = gsap.quickTo(borderGlow, 'x', { duration: 0.3, ease: 'power2.out' });
    const bY = gsap.quickTo(borderGlow, 'y', { duration: 0.3, ease: 'power2.out' });

    const rX = tilt ? gsap.quickTo(card, 'rotationX', { duration: 0.45, ease: 'power3.out' }) : null;
    const rY = tilt ? gsap.quickTo(card, 'rotationY', { duration: 0.45, ease: 'power3.out' }) : null;
    const yTo = tilt ? gsap.quickTo(card, 'y', { duration: 0.45, ease: 'power3.out' }) : null;

    if (tilt) {
      gsap.set(card, { transformPerspective: 1100 });
    }

    const onMove = (e: MouseEvent) => {
      const rect = card.getBoundingClientRect();
      const px = e.clientX - rect.left;
      const py = e.clientY - rect.top;

      gX(px);
      gY(py);
      bX(px);
      bY(py);

      if (tilt && rX && rY && yTo) {
        const nx = px / rect.width - 0.5;
        const ny = py / rect.height - 0.5;
        rY(nx * tiltStrength);
        rX(-ny * tiltStrength);
        yTo(-5);
      }
    };

    const onLeave = () => {
      if (tilt && rX && rY && yTo) {
        rX(0);
        rY(0);
        yTo(0);
      }
    };

    card.addEventListener('mousemove', onMove, { passive: true });
    card.addEventListener('mouseleave', onLeave);
    return () => {
      card.removeEventListener('mousemove', onMove);
      card.removeEventListener('mouseleave', onLeave);
    };
  }, [tilt, tiltStrength]);

  const toneClasses =
    tone === 'dark'
      ? 'border-white/[0.12] bg-[#16181D]/95 shadow-[0_14px_40px_-14px_rgba(0,0,0,0.65)] hover:border-[#F5A623]/75 hover:shadow-[0_24px_60px_-18px_rgba(245,166,35,0.22)]'
      : 'border-slate-950/[0.08] bg-white/95 shadow-[0_10px_30px_-10px_rgba(13,14,17,0.1)] hover:border-[#0D0E11]/35 hover:shadow-[0_24px_60px_-18px_rgba(13,14,17,0.16)]';

  return (
    <div
      ref={cardRef}
      onClick={onClick}
      data-cursor={cursorText}
      className={`group relative overflow-hidden rounded-3xl border transition-[border-color,box-shadow] duration-300 will-change-transform ${toneClasses} ${className}`}
    >
      {/* Cursor-tracked luminous border rim */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 rounded-3xl p-[1.5px] opacity-0 transition-opacity duration-300 group-hover:opacity-100 [mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)] [mask-composite:exclude] [-webkit-mask-composite:xor]"
      >
        <div
          ref={borderGlowRef}
          className="absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 h-64 w-64 rounded-full bg-[radial-gradient(circle,rgba(245,166,35,0.9)_0%,rgba(56,189,248,0.45)_42%,transparent_72%)]"
        />
      </div>

      {/* Inner surface soft studio glow */}
      <div
        ref={glowRef}
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 h-80 w-80 rounded-full bg-[radial-gradient(circle,rgba(245,166,35,0.09)_0%,rgba(56,189,248,0.04)_45%,transparent_72%)] opacity-0 transition-opacity duration-300 group-hover:opacity-100"
      />

      <div className="relative z-10 h-full">{children}</div>
    </div>
  );
}
