import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight } from 'lucide-react';
import { BRAND_ASSETS } from '../data/agencyData';
import type { AppRoute } from './Navbar';

gsap.registerPlugin(ScrollTrigger);

interface FooterProps {
  onNavigate: (route: AppRoute, hash?: string) => void;
}

const WORDMARK = 'TheXMarketeer'.split('');

export function Footer({ onNavigate }: FooterProps) {
  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = footerRef.current;
    if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.footer-letter',
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.025,
          duration: 0.75,
          ease: 'expo.out',
          force3D: true,
          clearProps: 'transform',
          scrollTrigger: {
            trigger: '.footer-wordmark',
            start: 'top 95%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, el);

    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="bg-[#0D0E11] text-white border-t border-white/10">
      <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12 pt-16 pb-10">
        <div className="grid grid-cols-1 gap-12 pb-14 border-b border-white/10 md:grid-cols-12">
          {/* Brand Summary */}
          <div className="md:col-span-4 space-y-5">
            <img
              src={BRAND_ASSETS.logoLight}
              alt="The XMarketeer Logo"
              className="h-32 sm:h-40 w-auto object-contain object-left transition-transform duration-300 hover:scale-[1.03]"
              referrerPolicy="no-referrer"
            />
            <p className="max-w-xs text-sm leading-relaxed text-white/65">
              A creative production and digital growth studio crafting commercial films, performance creatives, and scalable brand systems.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <a
                href="https://www.instagram.com/thexmarketeer0/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/[0.04] text-white/80 transition-all duration-300 hover:-translate-y-1 hover:scale-110 hover:border-[#F5A623] hover:bg-[#F5A623] hover:text-[#0D0E11] hover:shadow-[0_10px_24px_rgba(245,166,35,0.35)]"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
                  <rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" strokeWidth="2" />
                  <circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" strokeWidth="2" />
                  <circle cx="17.5" cy="6.5" r="1.2" fill="currentColor" />
                </svg>
              </a>
              <a
                href="https://www.linkedin.com/company/thexmarketeer"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/[0.04] text-white/80 transition-all duration-300 hover:-translate-y-1 hover:scale-110 hover:border-[#F5A623] hover:bg-[#F5A623] hover:text-[#0D0E11] hover:shadow-[0_10px_24px_rgba(245,166,35,0.35)]"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M5 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4ZM3.5 9h3v12h-3V9Zm5 0h2.9v1.6h.1A3.2 3.2 0 0 1 14.4 8c3.1 0 3.7 2 3.7 4.6V21h-3v-7.4c0-1.8-.1-3.2-2-3.2s-2.2 1.5-2.2 3.1V21h-3V9Z"
                  />
                </svg>
              </a>
              <a
                href="https://www.facebook.com/TheXMarketeer/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/[0.04] text-white/80 transition-all duration-300 hover:-translate-y-1 hover:scale-110 hover:border-[#F5A623] hover:bg-[#F5A623] hover:text-[#0D0E11] hover:shadow-[0_10px_24px_rgba(245,166,35,0.35)]"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.9.3-1.5 1.6-1.5h1.7V3.9c-.3 0-1.3-.1-2.4-.1-2.4 0-4.1 1.5-4.1 4.2V10H7.5v3h2.8v8h3.2Z"
                  />
                </svg>
              </a>
            </div>
          </div>

          {/* Services Links */}
          <div className="md:col-span-3 space-y-4">
            <h3 className="text-xs font-semibold tracking-wider text-[#F5A623] uppercase">
              Capabilities
            </h3>
            <ul className="space-y-2.5 text-sm text-white/65">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/services', 'video-production')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Video Production
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/services', 'graphic-design')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Graphic Designing
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/services', 'content-writing')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Content Writing
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('/services', 'social-media')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Social Media Marketing
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-2 space-y-4">
            <h3 className="text-xs font-semibold tracking-wider text-[#F5A623] uppercase">
              Agency
            </h3>
            <ul className="space-y-2.5 text-sm text-white/65">
              <li>
                <button type="button" onClick={() => onNavigate('/')} className="hover:text-white transition-colors cursor-pointer">
                  Home
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('/portfolio')} className="hover:text-white transition-colors cursor-pointer">
                  Video Portfolio
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('/portfolio', 'graphics')} className="hover:text-white transition-colors cursor-pointer">
                  Graphic Portfolio
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('/about')} className="hover:text-white transition-colors cursor-pointer">
                  About Us
                </button>
              </li>
              <li>
                <button type="button" onClick={() => onNavigate('/contact')} className="hover:text-white transition-colors cursor-pointer">
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="md:col-span-3 space-y-4">
            <h3 className="text-xs font-semibold tracking-wider text-[#F5A623] uppercase">
              Direct Studio Line
            </h3>
            <p className="text-base font-semibold text-white">
              If it&apos;s D2C, it&apos;s TheXMarketeer.
            </p>
            <div className="space-y-1.5 text-sm text-white/65">
              <p>
                <a href="mailto:thexmarketeer@gmail.com" className="hover:text-white transition-colors">
                  thexmarketeer@gmail.com
                </a>
              </p>
              <p>
                <a href="tel:+923422578815" className="hover:text-white transition-colors tabular-nums">
                  +92 342 2578815
                </a>
              </p>
              <p>Karachi, Pakistan</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('/contact')}
              className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[#F5A623] px-5 py-2.5 text-xs font-bold text-[#0D0E11] transition-colors hover:bg-white hover:text-[#0D0E11] cursor-pointer shadow-sm"
            >
              <span>Schedule Discovery Call</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Display Wordmark */}
        <div className="pt-10 text-center overflow-hidden">
          <div
            className="footer-wordmark font-display text-[10.5vw] sm:text-[9.5vw] lg:text-[124px] font-extrabold leading-none tracking-[-0.04em] select-none"
            aria-label="The XMarketeer"
          >
            {WORDMARK.map((char, idx) => (
              <span
                key={`${char}-${idx}`}
                className={`footer-letter inline-block ${
                  idx === 3 ? 'text-[#F5A623]' : 'text-white'
                }`}
              >
                {char}
              </span>
            ))}
          </div>
          <p className="mt-6 text-xs text-white/45">
            &copy; 2026 The XMarketeer. All rights reserved. Karachi, Pakistan.
          </p>
        </div>
      </div>
    </footer>
  );
}
