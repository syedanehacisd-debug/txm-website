import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';

export function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const [cursorLabel, setCursorLabel] = useState<string | null>(null);
  const [isInteractive, setIsInteractive] = useState(false);
  const [visible, setVisible] = useState(false);

  const visibleRef = useRef(false);
  const labelRef = useRef<string | null>(null);
  const interactiveRef = useRef(false);

  useEffect(() => {
    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduceMotion) return;

    const dot = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return;

    gsap.set([dot, ring], { xPercent: -50, yPercent: -50, force3D: true });

    const xDot = gsap.quickTo(dot, 'x', { duration: 0.1, ease: 'power3.out' });
    const yDot = gsap.quickTo(dot, 'y', { duration: 0.1, ease: 'power3.out' });
    const xRing = gsap.quickTo(ring, 'x', { duration: 0.34, ease: 'power3.out' });
    const yRing = gsap.quickTo(ring, 'y', { duration: 0.34, ease: 'power3.out' });

    const onMouseMove = (e: MouseEvent) => {
      if (!visibleRef.current) {
        visibleRef.current = true;
        setVisible(true);
      }
      xDot(e.clientX);
      yDot(e.clientY);
      xRing(e.clientX);
      yRing(e.clientY);

      const target = e.target as HTMLElement | null;
      if (!target) return;

      const labelEl = target.closest<HTMLElement>('[data-cursor]');
      const nextLabel = labelEl ? labelEl.dataset.cursor || null : null;
      const nextInteractive = nextLabel
        ? true
        : Boolean(target.closest('a, button, input, select, textarea, [role="button"]'));

      if (nextLabel !== labelRef.current) {
        labelRef.current = nextLabel;
        setCursorLabel(nextLabel);
      }
      if (nextInteractive !== interactiveRef.current) {
        interactiveRef.current = nextInteractive;
        setIsInteractive(nextInteractive);
      }
    };

    const onMouseLeave = () => {
      if (visibleRef.current) {
        visibleRef.current = false;
        setVisible(false);
      }
    };
    const onMouseEnter = () => {
      if (!visibleRef.current) {
        visibleRef.current = true;
        setVisible(true);
      }
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    document.addEventListener('mouseleave', onMouseLeave);
    document.addEventListener('mouseenter', onMouseEnter);

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseleave', onMouseLeave);
      document.removeEventListener('mouseenter', onMouseEnter);
    };
  }, []);

  return (
    <div
      className={`pointer-events-none fixed inset-0 z-[9999] hidden lg:block transition-opacity duration-300 ${
        visible ? 'opacity-100' : 'opacity-0'
      }`}
      aria-hidden="true"
    >
      <div
        ref={dotRef}
        className={`fixed top-0 left-0 rounded-full transition-all duration-150 ${
          cursorLabel ? 'h-0 w-0 opacity-0' : 'h-2 w-2 bg-[#F5A623] opacity-100'
        }`}
      />
      <div
        ref={ringRef}
        className={`fixed top-0 left-0 flex items-center justify-center rounded-full transition-all duration-300 ease-out ${
          cursorLabel
            ? 'h-20 w-20 bg-[#F5A623] text-slate-950 shadow-[0_12px_32px_rgba(245,166,35,0.4)]'
            : isInteractive
              ? 'h-12 w-12 border border-[#F5A623] bg-[#F5A623]/12'
              : 'h-9 w-9 border border-slate-900/30 bg-white/10 backdrop-blur-[1px]'
        }`}
      >
        {cursorLabel && (
          <span className="font-mono text-[10px] font-semibold tracking-widest uppercase">
            {cursorLabel}
          </span>
        )}
      </div>
    </div>
  );
}
