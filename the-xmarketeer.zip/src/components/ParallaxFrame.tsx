import { useEffect, useRef, type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface ParallaxFrameProps {
  children: ReactNode;
  className?: string;
  speed?: number;
  cursorText?: string;
  onClick?: () => void;
}

export function ParallaxFrame({
  children,
  className = '',
  speed = 6,
  cursorText,
  onClick,
}: ParallaxFrameProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    const inner = innerRef.current;
    if (!container || !inner) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        inner,
        { yPercent: -speed / 2, scale: 1.04 },
        {
          yPercent: speed / 2,
          scale: 1.04,
          ease: 'none',
          scrollTrigger: {
            trigger: container,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true,
          },
        }
      );
    }, container);

    return () => ctx.revert();
  }, [speed]);

  return (
    <div
      ref={containerRef}
      onClick={onClick}
      data-cursor={cursorText}
      className={`overflow-hidden ${className}`}
    >
      <div ref={innerRef} className="h-full w-full will-change-transform">
        {children}
      </div>
    </div>
  );
}

interface StatCounterProps {
  value: number;
  suffix: string;
  label: string;
  detail?: string;
  dark?: boolean;
}

export function StatCounter({ value, suffix, label, detail, dark = false }: StatCounterProps) {
  const numRef = useRef<HTMLSpanElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const numEl = numRef.current;
    const boxEl = boxRef.current;
    if (!numEl || !boxEl) return;

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      numEl.textContent = `${value}${suffix}`;
      return;
    }

    const counter = { val: 0 };
    const ctx = gsap.context(() => {
      gsap.to(counter, {
        val: value,
        duration: 1.6,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: boxEl,
          start: 'top 88%',
          once: true,
        },
        onUpdate: () => {
          numEl.textContent = `${Math.round(counter.val)}${suffix}`;
        },
      });
    }, boxEl);

    return () => ctx.revert();
  }, [value, suffix]);

  return (
    <div ref={boxRef} className="space-y-1">
      <div
        className={`font-mono text-3xl sm:text-4xl font-semibold tracking-tight tabular-nums ${
          dark ? 'text-white' : 'text-[#111111]'
        }`}
      >
        <span ref={numRef}>
          {value}
          {suffix}
        </span>
      </div>
      <div className={`text-sm font-medium ${dark ? 'text-white/80' : 'text-[#111111]'}`}>
        {label}
      </div>
      {detail && (
        <div className={`text-xs ${dark ? 'text-white/50' : 'text-[#666666]'}`}>{detail}</div>
      )}
    </div>
  );
}
