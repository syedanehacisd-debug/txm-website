import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowLeft, ArrowRight, ArrowUpRight, Play } from 'lucide-react';
import type { VideoReelItem } from '../data/agencyData';

gsap.registerPlugin(ScrollTrigger);
ScrollTrigger.config({ ignoreMobileResize: true });

interface MarketingReelDeckProps {
  reels: VideoReelItem[];
  onSelectVideo: (reel: VideoReelItem) => void;
  onViewAll: () => void;
}

export function MarketingReelDeck({
  reels,
  onSelectVideo,
  onViewAll,
}: MarketingReelDeckProps) {
  const stageRef = useRef<HTMLDivElement>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const stageGlowRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);
  const scrollTweenRef = useRef<gsap.core.Tween | null>(null);
  const activeIndexRef = useRef(0);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMobileOrTablet, setIsMobileOrTablet] = useState(false);

  // Track mobile/tablet breakpoint for auto-playing the centered active reel
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 1023px)');
    const sync = () => setIsMobileOrTablet(mq.matches);
    sync();
    mq.addEventListener('change', sync);
    return () => mq.removeEventListener('change', sync);
  }, []);

  // Cursor-following ambient spotlight across the Marketing Reel stage
  useEffect(() => {
    const stage = stageRef.current;
    const glow = stageGlowRef.current;
    if (!stage || !glow) return;

    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduceMotion) return;

    const gX = gsap.quickTo(glow, 'x', { duration: 0.6, ease: 'power3.out' });
    const gY = gsap.quickTo(glow, 'y', { duration: 0.6, ease: 'power3.out' });

    const onMove = (e: MouseEvent) => {
      const rect = stage.getBoundingClientRect();
      gX(e.clientX - rect.left);
      gY(e.clientY - rect.top);
    };

    stage.addEventListener('mousemove', onMove, { passive: true });
    return () => stage.removeEventListener('mousemove', onMove);
  }, []);

  // Unified Pinned Vertical-to-Horizontal 3D Scroll Choreography (Desktop, Tablet & Mobile)
  useEffect(() => {
    const stage = stageRef.current;
    const track = trackRef.current;
    const bar = progressBarRef.current;
    const header = headerRef.current;
    if (!stage || !track) return;

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const ctx = gsap.context(() => {
      if (header && !reduceMotion) {
        gsap.from(header.querySelectorAll('.reel-header-anim'), {
          x: -40,
          opacity: 0,
          stagger: 0.08,
          duration: 0.85,
          ease: 'expo.out',
          force3D: true,
          clearProps: 'transform',
          scrollTrigger: {
            trigger: stage,
            start: 'top 86%',
            once: true,
          },
        });
      }

      if (reduceMotion) return;

      const cards = gsap.utils.toArray<HTMLElement>('.reel-deck-card', track);
      const isCompact = () => window.innerWidth < 1024;
      const scrollDistance = () =>
        Math.max(0, track.scrollWidth - stage.clientWidth + (isCompact() ? 0 : 120));

      const applyCoverflowDepth = (progress: number) => {
        const count = cards.length;
        if (!count) return;
        const focal = progress * (count - 1);

        for (let i = 0; i < count; i++) {
          const offset = focal - i; // 0 = centered, positive = passed to left, negative = upcoming right
          const clamped = Math.max(-1.5, Math.min(1.5, offset));
          const abs = Math.abs(clamped);

          gsap.set(cards[i], {
            rotationY: clamped * 12,
            scale: 1.03 - Math.min(0.14, abs * 0.11),
            y: Math.min(18, abs * 14),
            opacity: Math.max(0.58, 1 - abs * 0.34),
            force3D: true,
          });
        }
      };

      // Set crisp initial coverflow pose on mount
      applyCoverflowDepth(0);

      const horizontalTween = gsap.to(track, {
        x: () => -scrollDistance(),
        ease: 'none',
        force3D: true,
        scrollTrigger: {
          trigger: stage,
          start: 'top top',
          end: () => `+=${Math.max(1200, scrollDistance() * (isCompact() ? 1.15 : 1.05) + 380)}`,
          pin: true,
          scrub: 0.45,
          invalidateOnRefresh: true,
          anticipatePin: 1,
          onUpdate: (self) => {
            if (bar) {
              bar.style.transform = `scaleX(${Math.max(0.08, self.progress)})`;
            }
            applyCoverflowDepth(self.progress);

            const idx = Math.min(
              reels.length - 1,
              Math.max(0, Math.round(self.progress * (reels.length - 1)))
            );
            if (idx !== activeIndexRef.current) {
              activeIndexRef.current = idx;
              setActiveIndex(idx);
            }
          },
        },
      });

      scrollTweenRef.current = horizontalTween;
    }, stage);

    return () => {
      scrollTweenRef.current = null;
      ctx.revert();
    };
  }, [reels.length]);

  const scrollToReel = (targetIdx: number) => {
    const clamped = Math.max(0, Math.min(reels.length - 1, targetIdx));
    const st = scrollTweenRef.current?.scrollTrigger;
    if (st) {
      const progress = clamped / Math.max(1, reels.length - 1);
      const targetScroll = st.start + (st.end - st.start) * progress;
      window.scrollTo({ top: targetScroll, behavior: 'smooth' });
      activeIndexRef.current = clamped;
      setActiveIndex(clamped);
    } else if (scrollerRef.current && trackRef.current) {
      const card = trackRef.current.children[clamped] as HTMLElement | undefined;
      if (card) {
        const scroller = scrollerRef.current;
        const sRect = scroller.getBoundingClientRect();
        const cRect = card.getBoundingClientRect();
        const targetLeft =
          scroller.scrollLeft + (cRect.left - sRect.left) - sRect.width / 2 + cRect.width / 2;
        scroller.scrollTo({ left: Math.max(0, targetLeft), behavior: 'smooth' });
      }
      activeIndexRef.current = clamped;
      setActiveIndex(clamped);
    }
  };

  return (
    <div
      ref={stageRef}
      className="relative min-h-[100svh] pt-24 pb-8 sm:pt-28 sm:pb-10 lg:py-0 flex flex-col justify-between lg:justify-center overflow-hidden bg-obsidian-studio text-white"
    >
      {/* Interactive Stage Spotlight */}
      <div
        ref={stageGlowRef}
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 h-[560px] w-[560px] rounded-full bg-[radial-gradient(circle,rgba(245,166,35,0.22)_0%,rgba(255,255,255,0.06)_45%,transparent_72%)] hidden lg:block"
      />

      {/* Header Row */}
      <div ref={headerRef} className="relative z-10 mx-auto w-full max-w-[1380px] px-5 sm:px-8 lg:px-12 lg:pt-14">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="reel-header-anim text-xs font-semibold tracking-widest text-[#F5A623] uppercase">
              Marketing Reels
            </p>
            <h2 className="reel-header-anim mt-1.5 font-display text-2xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white">
              Campaigns built for retention
            </h2>
          </div>

          <div className="reel-header-anim flex items-center justify-between sm:justify-end gap-3 sm:gap-4 w-full sm:w-auto">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => scrollToReel(activeIndex - 1)}
                aria-label="Previous reel"
                className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-full border border-white/15 bg-white/[0.06] text-white transition-all duration-200 hover:border-[#F5A623] hover:bg-[#F5A623] hover:text-[#0D0E11] hover:scale-105 cursor-pointer"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => scrollToReel(activeIndex + 1)}
                aria-label="Next reel"
                className="flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-full border border-white/15 bg-white/[0.06] text-white transition-all duration-200 hover:border-[#F5A623] hover:bg-[#F5A623] hover:text-[#0D0E11] hover:scale-105 cursor-pointer"
              >
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>

            <button
              type="button"
              onClick={onViewAll}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/[0.08] px-4 py-2 text-xs font-semibold text-white hover:border-[#F5A623] hover:bg-[#F5A623] hover:text-[#0D0E11] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>View Full Portfolio</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 3D Perspective Reel Track (Pinned Scroll-Scrubbed Horizontal Showcase Across All Viewports) */}
      <div
        ref={scrollerRef}
        className="relative z-10 my-auto py-4 sm:py-6 lg:my-0 lg:mt-10 lg:py-0 overflow-hidden [perspective:1600px]"
      >
        <div
          ref={trackRef}
          className="flex gap-5 sm:gap-7 lg:gap-9 w-max px-[calc(50vw-min(34vw,135px))] sm:px-[calc(50vw-145px)] lg:pl-[max(3rem,calc((100vw-1380px)/2+3rem))] lg:pr-[10vw] will-change-transform [transform-style:preserve-3d]"
        >
          {reels.map((reel, idx) => (
            <InteractiveReelCard
              key={reel.id}
              reel={reel}
              index={idx}
              isActive={idx === activeIndex}
              autoPlayOnActive={isMobileOrTablet}
              layoutClassName="w-[68vw] max-w-[270px] sm:w-[290px] lg:w-[300px] xl:w-[320px] shrink-0"
              aspectClassName="h-[46svh] min-h-[290px] max-h-[450px] lg:h-auto lg:max-h-none lg:aspect-[9/16]"
              onPlay={() => onSelectVideo(reel)}
            />
          ))}
        </div>
      </div>

      {/* Bottom Interactive Scrub Bar & Reel Index */}
      <div className="relative z-10 mx-auto w-full max-w-[1380px] px-5 sm:px-8 lg:px-12 mt-2 sm:mt-4 lg:mt-10 flex items-center justify-between gap-4 sm:gap-8">
        <div className="flex items-center gap-1 sm:gap-3 overflow-x-auto no-scrollbar">
          {reels.map((reel, idx) => (
            <button
              key={reel.id}
              type="button"
              onClick={() => scrollToReel(idx)}
              className={`font-mono text-xs transition-colors cursor-pointer px-1.5 py-1 shrink-0 ${
                idx === activeIndex
                  ? 'text-[#F5A623] font-bold'
                  : 'text-white/45 hover:text-white'
              }`}
            >
              0{idx + 1}
            </button>
          ))}
        </div>

        <div className="relative h-[3px] flex-1 max-w-md bg-white/15 overflow-hidden rounded-full">
          <div
            ref={progressBarRef}
            className="h-full w-full origin-left bg-[#F5A623] scale-x-[0.12] will-change-transform"
          />
        </div>

        <p className="hidden sm:block font-mono text-xs text-white/60 tabular-nums shrink-0">
          {reels[activeIndex]?.client} · 0{activeIndex + 1} / 0{reels.length}
        </p>
      </div>
    </div>
  );
}

export function InteractiveReelCard({
  reel,
  index,
  isActive = false,
  autoPlayOnActive = false,
  onPlay,
  layoutClassName = 'w-full lg:w-[300px] xl:w-[320px] shrink-0',
  aspectClassName = 'aspect-[9/16]',
}: {
  reel: VideoReelItem;
  index: number;
  isActive?: boolean;
  autoPlayOnActive?: boolean;
  onPlay: () => void;
  layoutClassName?: string;
  aspectClassName?: string;
}) {
  const cardRef = useRef<HTMLElement>(null);
  const sheenRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const infoRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState(false);

  const showActiveMotion = hovered || (autoPlayOnActive && isActive);

  useEffect(() => {
    if (!autoPlayOnActive) return;
    const video = videoRef.current;
    if (!video) return;
    if (isActive) {
      video.play().catch(() => {});
    } else {
      video.pause();
    }
  }, [autoPlayOnActive, isActive]);

  useEffect(() => {
    const card = cardRef.current;
    const sheen = sheenRef.current;
    if (!card) return;

    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduceMotion) return;

    const rX = gsap.quickTo(card, 'rotationX', { duration: 0.4, ease: 'power3.out' });
    const rY = gsap.quickTo(card, 'rotationY', { duration: 0.4, ease: 'power3.out' });
    const sX = sheen ? gsap.quickTo(sheen, 'x', { duration: 0.35, ease: 'power2.out' }) : null;
    const sY = sheen ? gsap.quickTo(sheen, 'y', { duration: 0.35, ease: 'power2.out' }) : null;

    const handleMove = (e: MouseEvent) => {
      const rect = card.getBoundingClientRect();
      const nx = (e.clientX - rect.left) / rect.width - 0.5;
      const ny = (e.clientY - rect.top) / rect.height - 0.5;

      rY(nx * 14);
      rX(-ny * 12);

      if (sX && sY) {
        sX(e.clientX - rect.left);
        sY(e.clientY - rect.top);
      }
    };

    const handleLeave = () => {
      rX(0);
      rY(0);
    };

    card.addEventListener('mousemove', handleMove, { passive: true });
    card.addEventListener('mouseleave', handleLeave);

    return () => {
      card.removeEventListener('mousemove', handleMove);
      card.removeEventListener('mouseleave', handleLeave);
    };
  }, []);

  const handleEnter = () => {
    setHovered(true);
    videoRef.current?.play().catch(() => {});
    if (infoRef.current && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      gsap.to(infoRef.current, { y: -4, duration: 0.35, ease: 'power3.out' });
    }
  };

  const handleLeave = () => {
    setHovered(false);
    if (videoRef.current && !(autoPlayOnActive && isActive)) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
    if (infoRef.current && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      gsap.to(infoRef.current, { y: 0, duration: 0.35, ease: 'power3.out' });
    }
  };

  return (
    <article
      ref={cardRef}
      onClick={onPlay}
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
      data-cursor="PLAY"
      className={`reel-deck-card hover-sheen group relative overflow-hidden rounded-2xl border bg-[#1E1F20] cursor-pointer transition-[border-color,box-shadow] duration-300 will-change-transform [transform-style:preserve-3d] ${layoutClassName} ${aspectClassName} ${
        showActiveMotion
          ? 'border-[#F5A623]/80 shadow-[0_24px_60px_-15px_rgba(245,166,35,0.22)]'
          : 'border-white/[0.12] hover:border-[#F5A623]/75'
      }`}
    >
      <video
        ref={videoRef}
        poster={reel.poster}
        muted
        loop
        playsInline
        preload="metadata"
        className={`h-full w-full object-cover transition-transform duration-700 ease-out ${
          showActiveMotion ? 'scale-105' : 'group-hover:scale-110'
        }`}
      >
        <source src={reel.videoUrl} type="video/mp4" />
      </video>

      {/* Cursor-following glossy light sheen */}
      <div
        ref={sheenRef}
        aria-hidden="true"
        className={`pointer-events-none absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 h-64 w-64 rounded-full bg-[radial-gradient(circle,rgba(245,166,35,0.24)_0%,transparent_70%)] transition-opacity duration-300 ${
          hovered ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* Contrast Scrim */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-black/25" />

      {/* Top Metadata + Kinetic Equalizer Motion Bars */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between text-xs text-white/80">
        <div className="flex items-center gap-2">
          <span className="font-mono">0{index + 1}</span>
          <span
            aria-hidden="true"
            className={`inline-flex items-end gap-[2px] h-3 transition-opacity duration-300 ${
              showActiveMotion ? 'opacity-100' : 'opacity-35'
            }`}
          >
            <span
              className={`w-[2px] bg-[#F5A623] rounded-full transition-all duration-300 ${
                showActiveMotion ? 'h-3 animate-pulse' : 'h-1.5'
              }`}
            />
            <span
              className={`w-[2px] bg-[#F5A623] rounded-full transition-all duration-300 ${
                showActiveMotion ? 'h-2 animate-pulse' : 'h-2.5'
              }`}
              style={{ animationDelay: '120ms' }}
            />
            <span
              className={`w-[2px] bg-[#F5A623] rounded-full transition-all duration-300 ${
                showActiveMotion ? 'h-3 animate-pulse' : 'h-1'
              }`}
              style={{ animationDelay: '240ms' }}
            />
          </span>
        </div>
        <span className="rounded-full bg-black/45 px-2.5 py-0.5 text-[11px] backdrop-blur-sm border border-white/10">
          {reel.category}
        </span>
      </div>

      {/* Animated Top Amber Accent Line on Active / Hover */}
      <div
        aria-hidden="true"
        className={`absolute top-0 left-0 right-0 h-[2px] bg-[#F5A623] origin-left transition-transform duration-500 ${
          showActiveMotion ? 'scale-x-100' : 'scale-x-0'
        }`}
      />

      {/* Bottom Info & Animated Play Trigger */}
      <div ref={infoRef} className="absolute bottom-5 left-5 right-5 space-y-3 will-change-transform">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-medium text-[#F5A623]">{reel.client}</p>
            <h3 className="mt-0.5 font-display text-lg font-bold leading-tight text-white">
              {reel.title}
            </h3>
          </div>
          <span
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-all duration-300 ${
              showActiveMotion
                ? 'bg-[#F5A623] text-[#131314] scale-110 shadow-[0_0_24px_rgba(245,166,35,0.45)]'
                : 'bg-white/15 text-white group-hover:bg-[#F5A623] group-hover:text-[#131314] group-hover:scale-110'
            }`}
          >
            <Play className="h-4 w-4 fill-current ml-0.5" />
          </span>
        </div>

        <p
          className={`text-xs leading-relaxed text-white/75 transition-all duration-300 overflow-hidden ${
            showActiveMotion ? 'max-h-16 opacity-100' : 'max-h-0 opacity-0'
          }`}
        >
          {reel.description}
        </p>
      </div>
    </article>
  );
}
