import { useEffect } from 'react';
import { X } from 'lucide-react';
import type { GraphicAssetItem, VideoReelItem } from '../data/agencyData';

interface VideoModalProps {
  reel: VideoReelItem | null;
  onClose: () => void;
}

export function VideoModal({ reel, onClose }: VideoModalProps) {
  useEffect(() => {
    if (!reel) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [reel, onClose]);

  if (!reel) return null;

  return (
    <div
      className="fixed inset-0 z-[2000] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 sm:p-8"
      role="dialog"
      aria-modal="true"
      aria-label={reel.title}
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-[440px] flex flex-col gap-3"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between text-white">
          <div>
            <p className="text-xs text-[#F5A623]">
              {reel.client} · {reel.category}
            </p>
            <h3 className="font-display text-lg font-semibold">{reel.title}</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close video modal"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 text-white transition-colors hover:bg-[#F5A623] hover:text-[#0A0A0A] cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-hidden rounded-2xl border border-white/15 bg-black aspect-[9/16] max-h-[78vh]">
          <video
            src={reel.videoUrl}
            poster={reel.poster}
            controls
            autoPlay
            playsInline
            className="h-full w-full object-cover"
          />
        </div>
      </div>
    </div>
  );
}

interface GraphicLightboxProps {
  asset: GraphicAssetItem | null;
  onClose: () => void;
}

export function GraphicLightbox({ asset, onClose }: GraphicLightboxProps) {
  useEffect(() => {
    if (!asset) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [asset, onClose]);

  if (!asset) return null;

  return (
    <div
      className="fixed inset-0 z-[2000] flex items-center justify-center bg-black/92 backdrop-blur-md p-4 sm:p-8"
      role="dialog"
      aria-modal="true"
      aria-label={asset.title}
      onClick={onClose}
    >
      <div
        className="relative max-w-4xl w-full flex flex-col items-center gap-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex w-full items-center justify-between text-white">
          <div>
            <p className="text-xs text-[#F5A623]">{asset.category}</p>
            <h3 className="font-display text-lg font-semibold">{asset.title}</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close lightbox"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 text-white transition-colors hover:bg-[#F5A623] hover:text-[#0A0A0A] cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <img
          src={asset.image}
          alt={asset.alt}
          referrerPolicy="no-referrer"
          className="max-h-[80vh] w-auto rounded-xl border border-white/10 object-contain"
        />
      </div>
    </div>
  );
}
