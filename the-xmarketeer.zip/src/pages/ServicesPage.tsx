import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, ArrowUpRight, Check } from 'lucide-react';
import { CAPABILITIES, PROCESS_STEPS } from '../data/agencyData';
import { MagneticButton } from '../components/MagneticButton';
import { StudioGlowCard } from '../components/StudioGlowCard';
import type { AppRoute } from '../components/Navbar';

gsap.registerPlugin(ScrollTrigger);

interface ServicesPageProps {
  onNavigate: (route: AppRoute, hash?: string) => void;
}

export function ServicesPage({ onNavigate }: ServicesPageProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const heroCopyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      gsap.from('.service-hero-in', {
        y: 26,
        opacity: 0,
        stagger: 0.08,
        duration: 0.8,
        ease: 'power3.out',
        clearProps: 'transform',
      });

      if (heroCopyRef.current) {
        gsap.to(heroCopyRef.current, {
          y: -40,
          opacity: 0.3,
          ease: 'none',
          force3D: true,
          scrollTrigger: {
            trigger: '.service-hero-section',
            start: 'top top',
            end: 'bottom 30%',
            scrub: true,
          },
        });
      }

      const blocks = gsap.utils.toArray<HTMLElement>('.service-block', root);
      blocks.forEach((block, idx) => {
        const fromLeft = idx % 2 === 0;
        gsap.fromTo(
          block,
          { x: fromLeft ? -72 : 72, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.9,
            ease: 'expo.out',
            force3D: true,
            clearProps: 'transform',
            scrollTrigger: {
              trigger: block,
              start: 'top 88%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });

      const processCards = gsap.utils.toArray<HTMLElement>('.process-card', root);
      processCards.forEach((card, idx) => {
        const fromLeft = idx % 2 === 0;
        gsap.fromTo(
          card,
          { x: fromLeft ? -56 : 56, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.85,
            delay: (idx % 2) * 0.06,
            ease: 'expo.out',
            force3D: true,
            clearProps: 'transform',
            scrollTrigger: {
              trigger: card,
              start: 'top 88%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, root);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={rootRef} className="overflow-x-clip bg-white text-slate-950">
      {/* Studio Header */}
      <section className="service-hero-section bg-studio-light text-slate-950 pt-32 pb-20 lg:pt-40 lg:pb-24 border-b border-slate-200 overflow-hidden">
        <div ref={heroCopyRef} className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12 will-change-transform">
          <div className="service-hero-in inline-flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/90 px-4 py-1.5 text-xs font-semibold tracking-wide text-slate-700 shadow-xs">
            <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
            <span>Agency Capabilities · In-House Execution</span>
          </div>
          <h1 className="service-hero-in mt-5 max-w-4xl font-display text-[clamp(2.4rem,4.8vw,4.1rem)] font-bold leading-[1.06] tracking-[-0.03em] text-slate-950 text-balance">
            Full-stack creative production &amp;{' '}
            <span className="bg-gradient-to-r from-[#D98A0B] via-[#F5A623] to-[#EA580C] bg-clip-text text-transparent">
              performance growth
            </span>
          </h1>
          <p className="service-hero-in mt-5 max-w-2xl text-base sm:text-lg leading-relaxed text-slate-600">
            Every discipline is executed in-house by strategists, cinematographers, visual designers, and media buyers aligned around measurable commercial outcomes.
          </p>
          <div className="service-hero-in mt-9 flex flex-wrap items-center gap-4">
            <MagneticButton
              onClick={() => onNavigate('/contact')}
              cursorText="START"
              className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-7 py-3.5 text-sm font-semibold text-white shadow-md transition-colors hover:bg-[#F5A623] hover:text-slate-950 cursor-pointer"
            >
              <span>Start a Project</span>
              <ArrowUpRight className="h-4 w-4" />
            </MagneticButton>
            <button
              type="button"
              onClick={() => onNavigate('/portfolio')}
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-6 py-3.5 text-sm font-semibold text-slate-900 shadow-xs hover:border-[#F5A623] transition-colors cursor-pointer"
            >
              <span>View Live Portfolio</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Capability Modules (OBSIDIAN BLACK) */}
      <section className="bg-obsidian-studio text-white py-20 lg:py-28">
        <div className="service-list mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12 space-y-12 lg:space-y-16">
          {CAPABILITIES.map((cap, idx) => {
            const reverse = idx % 2 === 1;
            return (
              <article key={cap.id} id={cap.id} className="service-block will-change-transform">
                <StudioGlowCard tone="dark" className="p-6 sm:p-10">
                  <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12 lg:gap-12">
                    <div className={`lg:col-span-6 ${reverse ? 'lg:order-2' : ''}`}>
                      <div className="hover-sheen overflow-hidden rounded-2xl border border-white/10 aspect-[16/9] bg-[#EAEAEA] flex items-center justify-center">
                        <img
                          src={cap.image}
                          alt={cap.title}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-[1.03]"
                        />
                      </div>
                    </div>

                    <div className={`lg:col-span-6 space-y-5 ${reverse ? 'lg:order-1' : ''}`}>
                      <p className="font-mono text-xs font-semibold text-[#F5A623]">
                        {cap.index}. {cap.category}
                      </p>
                      <h2 className="font-display text-2xl sm:text-4xl font-bold tracking-tight text-white transition-colors duration-300 group-hover:text-[#FFD17A]">
                        {cap.title}
                      </h2>
                      <p className="text-base leading-relaxed text-white/70">{cap.description}</p>

                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                        {cap.features.map((feat) => (
                          <li
                            key={feat}
                            className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-[#0D0E11]/75 px-3.5 py-2.5 text-sm font-medium text-white/90 transition-all duration-300 hover:border-[#F5A623]/60 hover:translate-x-1"
                          >
                            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#F5A623]/20 text-[#F5A623]">
                              <Check className="h-3 w-3" />
                            </span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>

                      <div className="pt-3">
                        <button
                          type="button"
                          onClick={() => onNavigate(cap.ctaTarget, cap.ctaHash)}
                          className="group/btn inline-flex items-center gap-2 rounded-full bg-[#F5A623] px-5 py-2.5 text-xs font-bold text-[#0D0E11] transition-all duration-300 hover:bg-white hover:shadow-[0_10px_24px_-8px_rgba(245,166,35,0.45)] cursor-pointer"
                        >
                          <span>{cap.ctaLabel}</span>
                          <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover/btn:translate-x-1" />
                        </button>
                      </div>
                    </div>
                  </div>
                </StudioGlowCard>
              </article>
            );
          })}
        </div>
      </section>

      {/* 4-Steps Project Process (SIGNATURE BRAND YELLOW) */}
      <section className="bg-yellow-studio text-[#0D0E11] py-20 lg:py-28 border-t border-black/10">
        <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#0D0E11] px-3.5 py-1 text-[11px] font-bold tracking-widest text-[#F5A623] uppercase">
              Methodology
            </span>
            <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#0D0E11]">
              Our 4-step production workflow
            </h2>
            <p className="mt-3 text-base font-medium text-[#0D0E11]/75">
              A repeatable workflow taking your brand from initial strategy brief to creative scaling.
            </p>
          </div>

          <div className="process-grid mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {PROCESS_STEPS.map((item) => (
              <div key={item.step} className="process-card will-change-transform">
                <StudioGlowCard tilt tiltStrength={7} className="hover-sheen h-full p-7">
                  <span className="font-mono text-3xl font-bold text-[#0D0E11] tabular-nums transition-transform duration-300 inline-block group-hover:translate-x-1">
                    {item.step}
                  </span>
                  <h3 className="mt-4 font-display text-xl font-bold tracking-tight text-[#0D0E11] transition-colors duration-300 group-hover:text-[#D98A0B]">
                    {item.title}
                  </h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-slate-600">{item.description}</p>
                  <div
                    aria-hidden="true"
                    className="mt-5 h-[2px] w-full origin-left scale-x-0 rounded-full bg-gradient-to-r from-[#0D0E11] to-[#F5A623] transition-transform duration-500 ease-out group-hover:scale-x-100"
                  />
                </StudioGlowCard>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
