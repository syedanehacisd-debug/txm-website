import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  Film,
  Layers,
  Megaphone,
  PenTool,
  Play,
  Sparkles,
} from 'lucide-react';
import {
  BRAND_ASSETS,
  CAPABILITIES,
  GRAPHIC_ASSETS,
  HERO_METRICS,
  PARTNER_LOGOS,
  TEAM_MEMBERS,
  VIDEO_REELS,
  type GraphicAssetItem,
  type VideoReelItem,
} from '../data/agencyData';
import { MagneticButton } from '../components/MagneticButton';
import { MarketingReelDeck } from '../components/MarketingReelDeck';
import { ParallaxFrame, StatCounter } from '../components/ParallaxFrame';
import { StudioGlowCard } from '../components/StudioGlowCard';
import type { AppRoute } from '../components/Navbar';

gsap.registerPlugin(ScrollTrigger);

interface HomePageProps {
  onNavigate: (route: AppRoute, hash?: string) => void;
  onSelectVideo: (reel: VideoReelItem) => void;
  onSelectGraphic: (asset: GraphicAssetItem) => void;
}

const STUDIO_MODULES = [
  {
    id: 'video-production',
    label: 'Video Production',
    icon: Film,
    briefPrompt: 'Produce a 4K commercial launch film + 6 vertical direct-response Meta & TikTok hooks.',
    headline: '4K commercial films & direct-response social cuts',
    summary:
      'From concept scripting and multi-cam lighting on set to sound design and color grading—built to hold attention past the first 1.5 seconds.',
    timeline: '7–14 days turnaround',
    channels: 'Meta · TikTok · YouTube · TVC',
    deliverables: ['4K Master Film', '9:16 Hook Variations', 'Sound Design & Grade', 'Raw Asset Library'],
    previewType: 'video' as const,
    poster: '/assets/aistudio/remove_he_tittle_202605211318_31a559fb_31a559fb.jpeg',
    reel: VIDEO_REELS[5],
  },
  {
    id: 'graphic-design',
    label: 'Visual Identity',
    icon: Layers,
    briefPrompt: 'Design a cohesive D2C brand system, packaging collateral, and 12 paid social statics.',
    headline: 'Brand systems, ad creatives & packaging collateral',
    summary:
      'Clean typography, unmistakable brand books, and modular static/carousel ad variations crafted to stand apart in crowded social feeds.',
    timeline: '5–10 days turnaround',
    channels: 'Brand Systems · Paid Social · Print',
    deliverables: ['Brand Identity Guide', 'Static Ad Matrices', 'Onboarding Suites', 'Packaging Artwork'],
    previewType: 'image' as const,
    poster: '/assets/aistudio/I_WANT_graphic_production_202605231540_4f0c93f9_4f0c93f9.jpeg',
    reel: VIDEO_REELS[0],
  },
  {
    id: 'content-writing',
    label: 'Ad Copywriting',
    icon: PenTool,
    briefPrompt: 'Script high-retention video openings, landing page headlines, and retention email flows.',
    headline: 'Sharp positioning, video hooks & conversion copy',
    summary:
      'Messaging rooted in buyer psychology. We script high-retention video openings, landing pages, and email sequences that move prospects to act.',
    timeline: '3–5 days turnaround',
    channels: 'Video Scripts · Web Copy · Email',
    deliverables: ['Hook & Script Matrix', 'Landing Page Copy', 'Brand Voice Playbook', 'Retention Email Flows'],
    previewType: 'image' as const,
    poster: '/assets/aistudio/i_want_this_type_of_202605231650_a6e1173a_a6e1173a.jpeg',
    reel: VIDEO_REELS[1],
  },
  {
    id: 'social-media',
    label: 'Paid Growth',
    icon: Megaphone,
    briefPrompt: 'Launch full-funnel Meta & TikTok creative sprints with weekly ROAS attribution.',
    headline: 'Full-funnel Meta, TikTok & creator distribution',
    summary:
      'Structured creative testing paired with weekly attribution reporting to scale return on ad spend and lower acquisition costs consistently.',
    timeline: 'Monthly creative sprint',
    channels: 'Meta Ads · TikTok · Creator UGC',
    deliverables: ['Creative Testing Matrix', 'Audience Architecture', 'Creator Orchestration', 'Weekly ROAS Audits'],
    previewType: 'image' as const,
    poster: '/assets/aistudio/make_a_image_like_this_202605231655_2d039307_2d039307.jpeg',
    reel: VIDEO_REELS[2],
  },
];

export function HomePage({ onNavigate, onSelectVideo, onSelectGraphic }: HomePageProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const heroSectionRef = useRef<HTMLElement>(null);
  const heroCopyRef = useRef<HTMLDivElement>(null);
  const workbenchOuterRef = useRef<HTMLDivElement>(null);
  const heroSpotlightRef = useRef<HTMLDivElement>(null);
  const workbenchPanelRef = useRef<HTMLDivElement>(null);
  const cinemaOrbRef = useRef<HTMLDivElement>(null);
  const cinemaFrameRef = useRef<HTMLDivElement>(null);

  // Scroll-reactive section refs
  const overviewSectionRef = useRef<HTMLElement>(null);
  const bentoLeftRef = useRef<HTMLDivElement>(null);
  const bentoRightRef = useRef<HTMLDivElement>(null);
  const deliverablesSectionRef = useRef<HTMLElement>(null);
  const marqueeWrapOneRef = useRef<HTMLDivElement>(null);
  const marqueeWrapTwoRef = useRef<HTMLDivElement>(null);
  const closingSectionRef = useRef<HTMLElement>(null);
  const closingCardRef = useRef<HTMLDivElement>(null);

  const [activeModuleIdx, setActiveModuleIdx] = useState(0);
  const [cinemaHovered, setCinemaHovered] = useState(false);
  const activeModule = STUDIO_MODULES[activeModuleIdx];

  // Smooth workbench transition when switching studio module tabs
  useEffect(() => {
    const panel = workbenchPanelRef.current;
    if (!panel) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    gsap.fromTo(
      panel,
      { opacity: 0, y: 10 },
      { opacity: 1, y: 0, duration: 0.35, ease: 'power3.out', force3D: true }
    );
  }, [activeModuleIdx]);

  // Subtle ambient cursor follow across hero light stage
  useEffect(() => {
    const root = rootRef.current;
    const spot = heroSpotlightRef.current;
    if (!root || !spot) return;

    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduceMotion) return;

    const sX = gsap.quickTo(spot, 'x', { duration: 0.55, ease: 'power2.out' });
    const sY = gsap.quickTo(spot, 'y', { duration: 0.55, ease: 'power2.out' });

    const onMove = (e: MouseEvent) => {
      sX(e.clientX);
      sY(e.clientY + window.scrollY);
    };

    window.addEventListener('mousemove', onMove, { passive: true });
    return () => window.removeEventListener('mousemove', onMove);
  }, []);

  // Floating magnetic play orb inside showreel bento frame
  useEffect(() => {
    const frame = cinemaFrameRef.current;
    const orb = cinemaOrbRef.current;
    if (!frame || !orb) return;

    const canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!canHover || reduceMotion) return;

    gsap.set(orb, { xPercent: -50, yPercent: -50 });
    const xTo = gsap.quickTo(orb, 'x', { duration: 0.3, ease: 'power3.out' });
    const yTo = gsap.quickTo(orb, 'y', { duration: 0.3, ease: 'power3.out' });

    const onMove = (e: MouseEvent) => {
      const rect = frame.getBoundingClientRect();
      xTo(e.clientX - rect.left);
      yTo(e.clientY - rect.top);
    };

    frame.addEventListener('mousemove', onMove, { passive: true });
    return () => frame.removeEventListener('mousemove', onMove);
  }, []);

  // Comprehensive GSAP ScrollTrigger choreography (GPU-composited side glides + smooth scrub)
  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      // 1. Initial Hero Entrance
      gsap.from('.studio-hero-in', {
        y: 22,
        opacity: 0,
        stagger: 0.07,
        duration: 0.75,
        ease: 'expo.out',
        force3D: true,
        clearProps: 'transform',
      });

      // Floating telemetry pills gentle ambient bob
      gsap.to('.hero-float-badge', {
        y: -8,
        duration: 2.6,
        stagger: 0.4,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });

      // 2. Hero Scroll-Linked Exit Parallax
      if (heroSectionRef.current && heroCopyRef.current && workbenchOuterRef.current) {
        gsap.to(heroCopyRef.current, {
          y: -60,
          opacity: 0.25,
          ease: 'none',
          force3D: true,
          scrollTrigger: {
            trigger: heroSectionRef.current,
            start: 'top top',
            end: 'bottom 24%',
            scrub: true,
          },
        });

        gsap.fromTo(
          workbenchOuterRef.current,
          { scale: 0.99, y: 0 },
          {
            scale: 1.015,
            y: -20,
            ease: 'none',
            force3D: true,
            scrollTrigger: {
              trigger: heroSectionRef.current,
              start: 'top top',
              end: 'bottom top',
              scrub: true,
            },
          }
        );
      }

      // 3. Studio Overview Section: Silky GPU Side-Entry Glides (left & right)
      if (overviewSectionRef.current) {
        const overviewHeaders = gsap.utils.toArray<HTMLElement>('.overview-head-anim', overviewSectionRef.current);
        overviewHeaders.forEach((el, idx) => {
          const fromLeft = idx < 2;
          gsap.fromTo(
            el,
            { x: fromLeft ? -56 : 56, opacity: 0 },
            {
              x: 0,
              opacity: 1,
              duration: 0.85,
              ease: 'expo.out',
              force3D: true,
              clearProps: 'transform',
              scrollTrigger: {
                trigger: overviewSectionRef.current,
                start: 'top 86%',
                toggleActions: 'play none none reverse',
              },
            }
          );
        });

        if (bentoLeftRef.current) {
          gsap.fromTo(
            bentoLeftRef.current,
            { x: -75, opacity: 0 },
            {
              x: 0,
              opacity: 1,
              duration: 0.9,
              ease: 'expo.out',
              force3D: true,
              clearProps: 'transform',
              scrollTrigger: {
                trigger: '.bento-grid-wrap',
                start: 'top 86%',
                toggleActions: 'play none none reverse',
              },
            }
          );
        }

        if (bentoRightRef.current) {
          gsap.fromTo(
            bentoRightRef.current,
            { x: 75, opacity: 0 },
            {
              x: 0,
              opacity: 1,
              duration: 0.9,
              delay: 0.07,
              ease: 'expo.out',
              force3D: true,
              clearProps: 'transform',
              scrollTrigger: {
                trigger: '.bento-grid-wrap',
                start: 'top 86%',
                toggleActions: 'play none none reverse',
              },
            }
          );
        }

        const mmCaps = gsap.matchMedia();
        const capCards = gsap.utils.toArray<HTMLElement>('.cap-bento-card', overviewSectionRef.current);

        mmCaps.add('(min-width: 1024px)', () => {
          const xOffsets = [-80, -44, 44, 80];
          capCards.forEach((card, idx) => {
            gsap.fromTo(
              card,
              { x: xOffsets[idx % 4], opacity: 0 },
              {
                x: 0,
                opacity: 1,
                duration: 0.9,
                delay: (idx % 2) * 0.06,
                ease: 'expo.out',
                force3D: true,
                clearProps: 'transform',
                scrollTrigger: {
                  trigger: '.cap-bento-grid',
                  start: 'top 88%',
                  toggleActions: 'play none none reverse',
                },
              }
            );
          });
        });

        mmCaps.add('(max-width: 1023px)', () => {
          capCards.forEach((card, idx) => {
            const fromLeft = idx % 2 === 0;
            gsap.fromTo(
              card,
              { x: fromLeft ? -64 : 64, opacity: 0 },
              {
                x: 0,
                opacity: 1,
                duration: 0.85,
                ease: 'expo.out',
                force3D: true,
                clearProps: 'transform',
                scrollTrigger: {
                  trigger: card,
                  start: 'top 88%',
                  toggleActions: 'play none none reverse',
                },
              }
            );
          });
        });
      }

      // 4. Client Deliverables Side-Entry + Staggered Partner Grid
      if (deliverablesSectionRef.current) {
        const delivHeaders = gsap.utils.toArray<HTMLElement>('.deliverables-head-anim', deliverablesSectionRef.current);
        delivHeaders.forEach((el, idx) => {
          const fromLeft = idx < 2;
          gsap.fromTo(
            el,
            { x: fromLeft ? -56 : 56, opacity: 0 },
            {
              x: 0,
              opacity: 1,
              duration: 0.85,
              ease: 'expo.out',
              force3D: true,
              clearProps: 'transform',
              scrollTrigger: {
                trigger: deliverablesSectionRef.current,
                start: 'top 86%',
                toggleActions: 'play none none reverse',
              },
            }
          );
        });

        if (marqueeWrapOneRef.current && marqueeWrapTwoRef.current) {
          gsap.fromTo(
            marqueeWrapOneRef.current,
            { x: -64, opacity: 0 },
            {
              x: 0,
              opacity: 1,
              duration: 0.95,
              ease: 'expo.out',
              force3D: true,
              clearProps: 'transform',
              scrollTrigger: {
                trigger: deliverablesSectionRef.current,
                start: 'top 82%',
                toggleActions: 'play none none reverse',
              },
            }
          );

          gsap.fromTo(
            marqueeWrapTwoRef.current,
            { x: 64, opacity: 0 },
            {
              x: 0,
              opacity: 1,
              duration: 0.95,
              delay: 0.08,
              ease: 'expo.out',
              force3D: true,
              clearProps: 'transform',
              scrollTrigger: {
                trigger: deliverablesSectionRef.current,
                start: 'top 82%',
                toggleActions: 'play none none reverse',
              },
            }
          );
        }

        const partnerTiles = gsap.utils.toArray<HTMLElement>('.partner-tile-anim', deliverablesSectionRef.current);
        gsap.fromTo(
          partnerTiles,
          { x: (i) => (i % 2 === 0 ? -36 : 36), opacity: 0 },
          {
            x: 0,
            opacity: 1,
            stagger: 0.035,
            duration: 0.7,
            ease: 'expo.out',
            force3D: true,
            clearProps: 'transform',
            scrollTrigger: {
              trigger: '.partner-grid-wrap',
              start: 'top 88%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }

      // 5. Closing Studio Card Smooth Entrance
      if (closingSectionRef.current && closingCardRef.current) {
        gsap.fromTo(
          closingCardRef.current,
          { y: 48, scale: 0.97, opacity: 0 },
          {
            y: 0,
            scale: 1,
            opacity: 1,
            duration: 0.9,
            ease: 'expo.out',
            force3D: true,
            clearProps: 'transform',
            scrollTrigger: {
              trigger: closingSectionRef.current,
              start: 'top 86%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, root);

    const refreshTimerA = window.setTimeout(() => ScrollTrigger.refresh(), 160);
    const refreshTimerB = window.setTimeout(() => ScrollTrigger.refresh(), 550);

    return () => {
      window.clearTimeout(refreshTimerA);
      window.clearTimeout(refreshTimerB);
      ctx.revert();
    };
  }, []);

  const marqueeRowOne = GRAPHIC_ASSETS.slice(0, 6);
  const marqueeRowTwo = GRAPHIC_ASSETS.slice(6, 12);

  return (
    <div ref={rootRef} className="relative overflow-x-clip bg-white text-slate-950">
      {/* Subtle Luminous Cursor Wash on White Canvas */}
      <div
        ref={heroSpotlightRef}
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 -translate-x-1/2 -translate-y-1/2 h-[760px] w-[760px] rounded-full bg-[radial-gradient(circle,rgba(245,166,35,0.1)_0%,rgba(56,189,248,0.06)_42%,transparent_70%)] hidden lg:block"
      />

      {/* 1. BRIGHT LUMINOUS STUDIO HERO + INTERACTIVE PRODUCTION WORKBENCH */}
      <section ref={heroSectionRef} className="relative pt-32 pb-14 lg:pt-40 lg:pb-20 bg-studio-light">
        <div className="relative z-10 mx-auto max-w-[1260px] px-5 sm:px-8 lg:px-12">
          {/* Centered Clean Geometric Headline */}
          <div ref={heroCopyRef} className="relative mx-auto max-w-3xl text-center will-change-transform">
            {/* Subtle Floating Spec Chips (Desktop architectural framing) */}
            <div
              aria-hidden="true"
              className="hero-float-badge hidden xl:flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/95 px-3.5 py-1.5 text-[11px] font-mono text-slate-700 shadow-sm absolute -left-36 top-6"
            >
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>4K RAW · 60fps</span>
            </div>
            <div
              aria-hidden="true"
              className="hero-float-badge hidden xl:flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/95 px-3.5 py-1.5 text-[11px] font-mono text-slate-700 shadow-sm absolute -right-32 top-16"
            >
              <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
              <span>150+ Productions</span>
            </div>

            <div className="studio-hero-in inline-flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/90 px-4 py-1.5 text-xs font-semibold tracking-wide text-slate-700 shadow-xs backdrop-blur-sm">
              <span className="h-2 w-2 rounded-full bg-[#F5A623] animate-pulse" />
              <span>Creative Production &amp; Growth Studio · Karachi</span>
            </div>

            <h1 className="studio-hero-in mt-5 font-display text-[clamp(2.5rem,5.4vw,4.5rem)] font-bold leading-[1.05] tracking-[-0.03em] text-slate-950 text-balance">
              Where creativity meets{' '}
              <span className="bg-gradient-to-r from-[#D98A0B] via-[#F5A623] to-[#EA580C] bg-clip-text text-transparent">
                strategy.
              </span>
            </h1>
            <p className="studio-hero-in mx-auto mt-5 max-w-2xl text-base sm:text-lg leading-relaxed text-slate-600">
              Build commercial films, direct-response UGC reels, and visual identity systems in one focused studio—engineered for modern D2C and enterprise brands.
            </p>

            <div className="studio-hero-in mt-8 flex flex-wrap items-center justify-center gap-4">
              <MagneticButton
                onClick={() => onNavigate('/contact')}
                cursorText="START"
                className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-7 py-3.5 text-sm font-semibold text-white shadow-md transition-colors hover:bg-[#F5A623] hover:text-slate-950 cursor-pointer"
              >
                <span>Start a Project</span>
                <ArrowUpRight className="h-4 w-4" />
              </MagneticButton>

              <button
                type="button"
                onClick={() => onSelectVideo(VIDEO_REELS[0])}
                className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-6 py-3.5 text-sm font-semibold text-slate-900 shadow-xs transition-all hover:border-[#F5A623] hover:shadow-md cursor-pointer"
              >
                <Play className="h-3.5 w-3.5 fill-current text-[#F5A623]" />
                <span>Watch Showreel</span>
              </button>
            </div>
          </div>

          {/* Signature Studio Workbench with Animated Luminous Gradient Halo */}
          <div ref={workbenchOuterRef} className="studio-hero-in mt-12 lg:mt-14 will-change-transform">
            <div className="studio-border-beam shadow-[0_28px_80px_-20px_rgba(15,23,42,0.14)]">
              <div className="rounded-[calc(1.75rem-1.5px)] bg-white/95 backdrop-blur-xl overflow-hidden">
                {/* Top Interactive Discipline Selector Bar */}
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200/80 bg-slate-50/75 px-5 py-4 sm:px-7">
                  <div
                    role="tablist"
                    aria-label="Creative Studio Modules"
                    className="flex flex-wrap items-center gap-2"
                  >
                    {STUDIO_MODULES.map((mod, idx) => {
                      const Icon = mod.icon;
                      const active = idx === activeModuleIdx;
                      return (
                        <button
                          key={mod.id}
                          type="button"
                          role="tab"
                          aria-selected={active}
                          onClick={() => setActiveModuleIdx(idx)}
                          className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs sm:text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                            active
                              ? 'bg-slate-950 text-white shadow-sm font-semibold'
                              : 'bg-white text-slate-600 border border-slate-200/80 hover:border-slate-300 hover:text-slate-950'
                          }`}
                        >
                          <Icon className={`h-3.5 w-3.5 ${active ? 'text-[#F5A623]' : ''}`} />
                          <span>{mod.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  <span className="hidden md:inline-flex items-center gap-2 rounded-full bg-white border border-slate-200/80 px-3 py-1 font-mono text-xs text-slate-600">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#F5A623]" />
                    {activeModule.timeline}
                  </span>
                </div>

                {/* Live Creative Brief Preview Prompt Line (Studio Workspace Vibe) */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-white px-5 py-3 sm:px-7">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Sparkles className="h-4 w-4 shrink-0 text-[#F5A623]" />
                    <p className="text-xs sm:text-sm font-medium text-slate-700 truncate">
                      {activeModule.briefPrompt}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate('/contact')}
                    className="inline-flex items-center gap-1 rounded-full bg-[#F5A623]/15 px-3 py-1 text-xs font-semibold text-[#B46900] hover:bg-[#F5A623] hover:text-slate-950 transition-colors cursor-pointer shrink-0"
                  >
                    <span>Book Sprint</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>
                </div>

                {/* Dual-Pane Workbench Content */}
                <div
                  ref={workbenchPanelRef}
                  className="grid grid-cols-1 gap-8 p-5 sm:p-8 lg:grid-cols-12 lg:items-center bg-white"
                >
                  {/* Left Visual Preview Frame */}
                  <div className="lg:col-span-6">
                    <div
                      onClick={() => onSelectVideo(activeModule.reel)}
                      data-cursor="WATCH"
                      className={`hover-sheen group/media relative aspect-video overflow-hidden rounded-2xl border border-slate-200 shadow-md cursor-pointer ${
                        activeModule.previewType === 'video' ? 'bg-slate-950' : 'bg-[#EAEAEA]'
                      }`}
                    >
                      {activeModule.previewType === 'video' ? (
                        <video
                          src={BRAND_ASSETS.sampleReelVideo}
                          poster={activeModule.poster}
                          muted
                          autoPlay
                          loop
                          playsInline
                          className="h-full w-full object-cover transition-transform duration-700 group-hover/media:scale-[1.03]"
                        />
                      ) : (
                        <img
                          src={activeModule.poster}
                          alt={activeModule.label}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-contain transition-transform duration-700 group-hover/media:scale-[1.03]"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between gap-3">
                        <span className="rounded-full bg-black/50 backdrop-blur-sm border border-white/15 px-3 py-1 text-xs font-medium text-white">
                          {activeModule.channels}
                        </span>
                        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#F5A623] text-slate-950 shadow-lg transition-transform group-hover/media:scale-110">
                          <Play className="h-4 w-4 fill-current ml-0.5" />
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Strategy & Deliverables Output */}
                  <div className="lg:col-span-6 space-y-5">
                    <div>
                      <p className="text-xs font-semibold tracking-wider text-[#D98A0B] uppercase">
                        {activeModule.label}
                      </p>
                      <h2 className="mt-1.5 font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
                        {activeModule.headline}
                      </h2>
                      <p className="mt-3 text-sm sm:text-base leading-relaxed text-slate-600">
                        {activeModule.summary}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      {activeModule.deliverables.map((item) => (
                        <div
                          key={item}
                          className="flex items-center gap-2.5 rounded-xl border border-slate-200/80 bg-slate-50 px-3.5 py-2.5 text-xs sm:text-sm font-medium text-slate-800 transition-all duration-200 hover:border-[#F5A623]/60 hover:bg-white hover:shadow-xs"
                        >
                          <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#F5A623]/20 text-[#B46900]">
                            <Check className="h-3 w-3" />
                          </span>
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex flex-wrap items-center gap-4 pt-2">
                      <button
                        type="button"
                        onClick={() => onNavigate('/services', activeModule.id)}
                        className="group/btn inline-flex items-center gap-2 rounded-full bg-slate-950 px-5 py-2.5 text-xs font-semibold text-white transition-all hover:bg-[#F5A623] hover:text-slate-950 cursor-pointer"
                      >
                        <span>Explore {activeModule.label}</span>
                        <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover/btn:translate-x-1" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onNavigate('/contact')}
                        className="text-xs font-semibold text-slate-600 hover:text-slate-950 transition-colors cursor-pointer"
                      >
                        Request Custom Scope
                      </button>
                    </div>
                  </div>
                </div>

                {/* Bottom Studio KPI Status Footer inside Workbench */}
                <div className="grid grid-cols-2 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-slate-200/75 border-t border-slate-200/80 bg-slate-50/70">
                  {HERO_METRICS.map((m) => (
                    <div key={m.label} className="px-5 py-3.5 flex items-center justify-between sm:block">
                      <p className="font-mono text-base sm:text-lg font-bold text-slate-950 tabular-nums">
                        {m.value}
                        {m.suffix}
                      </p>
                      <p className="text-[11px] font-medium text-slate-500">{m.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Scroll Prompt */}
          <div className="studio-hero-in mt-9 flex justify-center">
            <button
              type="button"
              onClick={() =>
                overviewSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
              }
              className="group inline-flex items-center gap-2.5 rounded-full border border-slate-200 bg-white px-4 py-2 text-[11px] font-mono tracking-widest text-slate-600 uppercase shadow-xs transition-all duration-300 hover:border-[#F5A623] hover:text-slate-950 cursor-pointer"
            >
              <span>Scroll to explore</span>
              <ArrowDown className="h-3.5 w-3.5 text-[#F5A623] transition-transform duration-300 group-hover:translate-y-0.5 animate-bounce" />
            </button>
          </div>
        </div>
      </section>

      {/* 1b. CONTINUOUS KINETIC DISCIPLINE RIBBON (OBSIDIAN BLACK) */}
      <div
        aria-hidden="true"
        className="overflow-hidden border-y border-white/10 bg-[#0D0E11] py-4 select-none"
      >
        <div className="animate-marquee-ribbon items-center whitespace-nowrap font-display text-xs sm:text-sm font-semibold tracking-[0.22em] text-white/55 uppercase">
          {[0, 1].map((half) => (
            <div key={half} className="flex items-center gap-8 pr-8 shrink-0">
              {[0, 1].map((dup) => (
                <div key={dup} className="flex items-center gap-8 shrink-0">
                  <span className="text-white">Commercial Cinematography</span>
                  <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
                  <span>Direct-Response UGC</span>
                  <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
                  <span className="text-white">Brand Identity Systems</span>
                  <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
                  <span>Paid Social Growth</span>
                  <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
                  <span className="text-white">Conversion Copywriting</span>
                  <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* 2. SIGNATURE BRAND YELLOW BENTO SHOWCASE (SHOWREEL + VELOCITY STATS + CREATIVE UNIT) */}
      <section ref={overviewSectionRef} className="bg-yellow-studio text-[#0D0E11] py-16 lg:py-24">
        <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between mb-10">
            <div>
              <span className="overview-head-anim inline-flex items-center gap-1.5 rounded-full bg-[#0D0E11] px-3.5 py-1 text-[11px] font-bold tracking-widest text-[#F5A623] uppercase">
                Studio Overview
              </span>
              <h2 className="overview-head-anim mt-3 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#0D0E11]">
                Built in-house from concept to distribution
              </h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('/about')}
              className="overview-head-anim inline-flex items-center gap-1.5 rounded-full bg-[#0D0E11] px-5 py-2.5 text-xs font-bold text-white shadow-md hover:bg-white hover:text-[#0D0E11] transition-colors cursor-pointer self-start sm:self-auto"
            >
              <span>Meet the Studio</span>
              <ArrowUpRight className="h-4 w-4" />
            </button>
          </div>

          <div className="bento-grid-wrap grid grid-cols-1 gap-6 lg:grid-cols-12">
            {/* Large Featured Showreel Card */}
            <div ref={bentoLeftRef} className="lg:col-span-7 will-change-transform">
              <StudioGlowCard className="h-full p-2.5 sm:p-3">
                <div
                  ref={cinemaFrameRef}
                  onClick={() => onSelectVideo(VIDEO_REELS[0])}
                  onMouseEnter={() => setCinemaHovered(true)}
                  onMouseLeave={() => setCinemaHovered(false)}
                  data-cursor="WATCH"
                  className="relative aspect-[16/10] w-full overflow-hidden rounded-2xl bg-slate-950 cursor-pointer"
                >
                  <ParallaxFrame className="h-full w-full" speed={12}>
                    <video
                      src={BRAND_ASSETS.sampleReelVideo}
                      poster="/assets/aistudio/make_it_in_this_size_202605071340_659449f6_659449f6.jpeg"
                      muted
                      autoPlay
                      loop
                      playsInline
                      className="h-full w-full object-cover opacity-90"
                    />
                  </ParallaxFrame>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-transparent" />

                  {/* Cursor-following Play Lens */}
                  <div
                    ref={cinemaOrbRef}
                    aria-hidden="true"
                    className={`pointer-events-none absolute top-0 left-0 z-20 hidden lg:flex h-20 w-20 items-center justify-center rounded-full bg-[#F5A623] text-slate-950 shadow-2xl transition-all duration-300 ${
                      cinemaHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-75'
                    }`}
                  >
                    <Play className="h-6 w-6 fill-current ml-0.5" />
                  </div>

                  <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
                    <div>
                      <p className="text-xs font-medium text-[#F5A623]">Featured Showreel</p>
                      <h3 className="mt-1 font-display text-xl sm:text-2xl font-bold text-white">
                        If it&apos;s D2C, it&apos;s TheXMarketeer.
                      </h3>
                    </div>
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/20 backdrop-blur-md text-white lg:hidden">
                      <Play className="h-4 w-4 fill-current ml-0.5" />
                    </span>
                  </div>
                </div>
              </StudioGlowCard>
            </div>

            {/* Right Column Stack: Metrics + Core Team */}
            <div ref={bentoRightRef} className="lg:col-span-5 flex flex-col gap-6 will-change-transform">
              <StudioGlowCard tilt tiltStrength={4} className="p-6 sm:p-7">
                <p className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
                  Studio Output
                </p>
                <div className="mt-5 grid grid-cols-2 gap-6">
                  {HERO_METRICS.map((m) => (
                    <StatCounter
                      key={m.label}
                      value={m.value}
                      suffix={m.suffix}
                      label={m.label}
                      detail={m.detail}
                      dark={false}
                    />
                  ))}
                </div>
              </StudioGlowCard>

              <StudioGlowCard
                tilt
                tiltStrength={4}
                onClick={() => onNavigate('/about')}
                cursorText="TEAM"
                className="flex-1 p-6 sm:p-7 cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold tracking-wider text-[#D98A0B] uppercase">
                      Core Creative Unit
                    </p>
                    <h3 className="mt-1 font-display text-lg font-bold text-slate-950">
                      Directors, editors &amp; growth strategists
                    </h3>
                  </div>
                  <ArrowUpRight className="h-4 w-4 text-slate-400 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-[#D98A0B]" />
                </div>

                <div className="mt-5 grid grid-cols-3 gap-3">
                  {TEAM_MEMBERS.map((member) => (
                    <div
                      key={member.role}
                      className="group/member overflow-hidden rounded-xl border border-slate-200 bg-slate-50 transition-colors duration-300 hover:border-[#F5A623]"
                    >
                      <div className="aspect-square overflow-hidden">
                        <img
                          src={member.image}
                          alt={member.name}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover object-top transition-transform duration-500 group-hover/member:scale-110"
                        />
                      </div>
                      <p className="px-2.5 py-2 text-[11px] font-semibold text-slate-700 truncate transition-colors group-hover/member:text-slate-950">
                        {member.name}
                      </p>
                    </div>
                  ))}
                </div>
              </StudioGlowCard>
            </div>
          </div>

          {/* 4-Card Capability Strip */}
          <div className="cap-bento-grid mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {CAPABILITIES.map((cap) => (
              <div key={cap.id} className="cap-bento-card will-change-transform">
                <StudioGlowCard
                  tilt
                  tiltStrength={7}
                  onClick={() => onNavigate('/services', cap.id)}
                  cursorText="OPEN"
                  className="hover-sheen h-full p-5 cursor-pointer"
                >
                  <div className="relative aspect-[16/9] overflow-hidden rounded-xl border border-slate-200 bg-[#EAEAEA] flex items-center justify-center">
                    <img
                      src={cap.image}
                      alt={cap.title}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-contain transition-transform duration-600 ease-out group-hover:scale-[1.04]"
                    />
                    <span className="absolute top-2.5 right-2.5 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-slate-900 shadow-sm opacity-0 -translate-x-1 translate-y-1 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0 group-hover:translate-y-0 group-hover:bg-[#F5A623] group-hover:text-slate-950">
                      <ArrowUpRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <p className="font-mono text-xs font-semibold text-[#D98A0B] transition-transform duration-300 group-hover:translate-x-1">
                      {cap.index}
                    </p>
                    <span className="text-[11px] font-medium text-slate-400 transition-colors duration-300 group-hover:text-[#D98A0B]">
                      {cap.category}
                    </span>
                  </div>
                  <h3 className="mt-1 font-display text-lg font-bold text-slate-950 leading-snug transition-colors duration-300 group-hover:text-[#B46900]">
                    {cap.title}
                  </h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-600">
                    {cap.summary}
                  </p>
                  <div
                    aria-hidden="true"
                    className="mt-4 h-[2px] w-full origin-left scale-x-0 rounded-full bg-gradient-to-r from-[#F5A623] to-[#38BDF8] transition-transform duration-500 ease-out group-hover:scale-x-100"
                  />
                </StudioGlowCard>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. 3D GSAP PINNED HORIZONTAL MARKETING REEL DECK */}
      <section className="border-t border-slate-200">
        <MarketingReelDeck
          reels={VIDEO_REELS}
          onSelectVideo={onSelectVideo}
          onViewAll={() => onNavigate('/portfolio')}
        />
      </section>

      {/* 4. CLIENT DELIVERABLES & PARTNER ROSTER */}
      <section
        ref={deliverablesSectionRef}
        className="bg-white-wash py-20 lg:py-24 border-t border-slate-200 overflow-hidden"
      >
        <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="deliverables-head-anim text-xs font-semibold tracking-widest text-[#D98A0B] uppercase">
                Client Deliverables
              </p>
              <h2 className="deliverables-head-anim mt-2 font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-950">
                Visual identity &amp; social campaign collateral
              </h2>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('/portfolio', 'graphics')}
              className="deliverables-head-anim inline-flex items-center gap-1.5 self-start sm:self-auto rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-semibold text-slate-900 shadow-xs hover:border-[#F5A623] hover:bg-slate-950 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Explore Graphic Archive</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        <div className="mt-12 space-y-5">
          <div ref={marqueeWrapOneRef} className="marquee-group overflow-hidden py-2 will-change-transform">
            <div className="animate-marquee gap-5 px-2.5">
              {[...marqueeRowOne, ...marqueeRowOne].map((item, idx) => (
                <button
                  key={`${item.id}-${idx}`}
                  type="button"
                  onClick={() => onSelectGraphic(item)}
                  data-cursor="VIEW"
                  className="hover-sheen group relative h-[288px] w-[232px] sm:h-[312px] sm:w-[250px] shrink-0 overflow-hidden rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm text-left transition-all duration-400 hover:-translate-y-2 hover:border-[#F5A623] hover:shadow-[0_24px_48px_-14px_rgba(15,23,42,0.18)] cursor-pointer"
                >
                  <div className="relative h-full w-full overflow-hidden rounded-xl bg-slate-100">
                    <img
                      src={item.image}
                      alt={item.alt}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-contain transition-transform duration-600 ease-out group-hover:scale-[1.04]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                    <div className="absolute inset-x-3 bottom-3 flex items-end justify-between gap-2 translate-y-3 opacity-0 transition-all duration-300 ease-out group-hover:translate-y-0 group-hover:opacity-100">
                      <div className="min-w-0">
                        <p className="text-[10px] font-mono tracking-wider text-[#F5A623] uppercase truncate">
                          {item.category}
                        </p>
                        <p className="text-xs font-semibold text-white truncate">{item.title}</p>
                      </div>
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#F5A623] text-slate-950">
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div ref={marqueeWrapTwoRef} className="marquee-group overflow-hidden py-2 will-change-transform">
            <div className="animate-marquee-reverse gap-5 px-2.5">
              {[...marqueeRowTwo, ...marqueeRowTwo].map((item, idx) => (
                <button
                  key={`${item.id}-rev-${idx}`}
                  type="button"
                  onClick={() => onSelectGraphic(item)}
                  data-cursor="VIEW"
                  className="hover-sheen group relative h-[288px] w-[232px] sm:h-[312px] sm:w-[250px] shrink-0 overflow-hidden rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm text-left transition-all duration-400 hover:-translate-y-2 hover:border-[#F5A623] hover:shadow-[0_24px_48px_-14px_rgba(15,23,42,0.18)] cursor-pointer"
                >
                  <div className="relative h-full w-full overflow-hidden rounded-xl bg-slate-100">
                    <img
                      src={item.image}
                      alt={item.alt}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-contain transition-transform duration-600 ease-out group-hover:scale-[1.04]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                    <div className="absolute inset-x-3 bottom-3 flex items-end justify-between gap-2 translate-y-3 opacity-0 transition-all duration-300 ease-out group-hover:translate-y-0 group-hover:opacity-100">
                      <div className="min-w-0">
                        <p className="text-[10px] font-mono tracking-wider text-[#F5A623] uppercase truncate">
                          {item.category}
                        </p>
                        <p className="text-xs font-semibold text-white truncate">{item.title}</p>
                      </div>
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#F5A623] text-slate-950">
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Partner Brand Strip */}
        <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12 mt-16">
          <p className="mb-6 text-xs font-semibold tracking-widest text-slate-500 uppercase">
            Brands We&apos;ve Partnered With
          </p>
          <div className="partner-grid-wrap grid grid-cols-3 gap-4 sm:grid-cols-5 lg:grid-cols-9">
            {PARTNER_LOGOS.map((partner) => (
              <div
                key={partner.name}
                className="partner-tile-anim group relative flex h-20 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-slate-50/70 p-3 shadow-xs transition-all duration-300 hover:-translate-y-1.5 hover:scale-105 hover:bg-white hover:border-[#F5A623] hover:shadow-[0_14px_30px_-10px_rgba(15,23,42,0.12)]"
              >
                <img
                  src={partner.logo}
                  alt={partner.name}
                  referrerPolicy="no-referrer"
                  className="max-h-11 w-auto object-contain transition-transform duration-300 group-hover:-translate-y-1.5 group-hover:scale-95"
                />
                <span className="absolute inset-x-1 bottom-1 truncate rounded-md bg-slate-950 px-1.5 py-0.5 text-center text-[9px] font-semibold text-[#F5A623] opacity-0 translate-y-2 transition-all duration-250 group-hover:opacity-100 group-hover:translate-y-0">
                  {partner.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. BRAND YELLOW & OBSIDIAN STUDIO CLOSING CARD */}
      <section
        ref={closingSectionRef}
        className="py-16 lg:py-24 bg-yellow-studio border-t border-black/10"
      >
        <div ref={closingCardRef} className="mx-auto max-w-[1260px] px-5 sm:px-8 lg:px-12 will-change-transform">
          <div className="rounded-[1.75rem] bg-white p-8 sm:p-14 text-center shadow-[0_28px_80px_-20px_rgba(13,14,17,0.22)] ring-1 ring-black/10">
            <div className="mx-auto max-w-2xl">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[#0D0E11] px-3.5 py-1 text-[11px] font-bold tracking-widest text-[#F5A623] uppercase">
                Start Your Campaign
              </span>
              <h2 className="mt-4 font-display text-3xl sm:text-5xl font-bold tracking-tight text-[#0D0E11] text-balance">
                Marketing never sleeps. Let&apos;s build your next launch.
              </h2>
              <p className="mt-4 text-base text-slate-600">
                Share your product timeline and campaign goals—our creative director replies within 24 hours.
              </p>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                <MagneticButton
                  onClick={() => onNavigate('/contact')}
                  cursorText="BOOK"
                  className="inline-flex items-center gap-2 rounded-full bg-[#0D0E11] px-7 py-3.5 text-sm font-semibold text-white shadow-md transition-colors hover:bg-[#F5A623] hover:text-[#0D0E11] cursor-pointer"
                >
                  <span>Start a Project</span>
                  <ArrowUpRight className="h-4 w-4" />
                </MagneticButton>
                <button
                  type="button"
                  onClick={() => onNavigate('/portfolio')}
                  className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-6 py-3.5 text-sm font-semibold text-slate-900 shadow-xs transition-all hover:border-[#0D0E11] hover:shadow-md cursor-pointer"
                >
                  <span>View Portfolio</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
