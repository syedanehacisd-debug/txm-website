import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, ArrowUpRight } from 'lucide-react';
import {
  BRAND_ASSETS,
  HERO_METRICS,
  PARTNER_LOGOS,
  TEAM_MEMBERS,
} from '../data/agencyData';
import { MagneticButton } from '../components/MagneticButton';
import { ParallaxFrame, StatCounter } from '../components/ParallaxFrame';
import { StudioGlowCard } from '../components/StudioGlowCard';
import type { AppRoute } from '../components/Navbar';

gsap.registerPlugin(ScrollTrigger);

interface AboutPageProps {
  onNavigate: (route: AppRoute) => void;
}

export function AboutPage({ onNavigate }: AboutPageProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const heroSplitLeftRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      gsap.from('.about-hero-in', {
        y: 28,
        opacity: 0,
        stagger: 0.08,
        duration: 0.8,
        ease: 'power3.out',
        clearProps: 'transform',
      });

      if (heroSplitLeftRef.current) {
        gsap.to(heroSplitLeftRef.current, {
          y: -36,
          opacity: 0.38,
          ease: 'none',
          force3D: true,
          scrollTrigger: {
            trigger: '.about-hero-section',
            start: 'top top',
            end: 'bottom 25%',
            scrub: true,
          },
        });
      }

      gsap.fromTo(
        '.about-story-left',
        { x: -72, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.9,
          ease: 'expo.out',
          force3D: true,
          clearProps: 'transform',
          scrollTrigger: {
            trigger: '.about-story-section',
            start: 'top 86%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        '.about-story-right',
        { x: 72, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.9,
          delay: 0.08,
          ease: 'expo.out',
          force3D: true,
          clearProps: 'transform',
          scrollTrigger: {
            trigger: '.about-story-section',
            start: 'top 86%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      const teamCards = gsap.utils.toArray<HTMLElement>('.team-card-anim', root);
      teamCards.forEach((card, idx) => {
        const fromLeft = idx % 2 === 0;
        gsap.fromTo(
          card,
          { x: fromLeft ? -68 : 68, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.85,
            delay: (idx % 2) * 0.06,
            ease: 'expo.out',
            force3D: true,
            clearProps: 'transform',
            scrollTrigger: {
              trigger: card,
              start: 'top 88%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, root);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={rootRef} className="overflow-x-clip bg-white text-slate-950">
      {/* Studio Hero Split */}
      <section className="about-hero-section bg-studio-light text-slate-950 pt-32 pb-20 lg:pt-40 lg:pb-24 overflow-hidden">
        <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-14">
            <div ref={heroSplitLeftRef} className="lg:col-span-6 space-y-6 will-change-transform">
              <div className="about-hero-in inline-flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/90 px-4 py-1.5 text-xs font-semibold tracking-wide text-slate-700 shadow-xs">
                <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
                <span>Who We Are · Karachi, Pakistan</span>
              </div>
              <h1 className="about-hero-in font-display text-[clamp(2.4rem,4.6vw,4rem)] font-bold leading-[1.06] tracking-[-0.03em] text-slate-950 text-balance">
                A creative production studio built for{' '}
                <span className="bg-gradient-to-r from-[#D98A0B] via-[#F5A623] to-[#EA580C] bg-clip-text text-transparent">
                  modern brands
                </span>
              </h1>
              <p className="about-hero-in text-base sm:text-lg leading-relaxed text-slate-600">
                The XMarketeer is a creative production and digital growth studio focused on commercial cinematography, direct-response UGC creatives, visual identity, and performance marketing.
              </p>
              <div className="about-hero-in flex flex-wrap items-center gap-4 pt-2">
                <MagneticButton
                  onClick={() => onNavigate('/contact')}
                  cursorText="START"
                  className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-7 py-3.5 text-sm font-semibold text-white shadow-md hover:bg-[#F5A623] hover:text-slate-950 transition-colors cursor-pointer"
                >
                  <span>Start Your Project</span>
                  <ArrowUpRight className="h-4 w-4" />
                </MagneticButton>
                <button
                  type="button"
                  onClick={() => onNavigate('/portfolio')}
                  className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-6 py-3.5 text-sm font-semibold text-slate-900 shadow-xs hover:border-[#F5A623] transition-colors cursor-pointer"
                >
                  <span>View Portfolio</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="about-hero-in lg:col-span-6">
              <div className="studio-border-beam shadow-[0_24px_60px_-20px_rgba(15,23,42,0.14)]">
                <ParallaxFrame className="hover-sheen rounded-[calc(1.75rem-1.5px)] aspect-video bg-slate-950" speed={4}>
                  <img
                    src={BRAND_ASSETS.studioHero}
                    alt="The XMarketeer Studio Production Crew"
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                  />
                </ParallaxFrame>
              </div>
            </div>
          </div>

          {/* 4-Column KPI Strip */}
          <div className="mt-16 grid grid-cols-2 gap-8 border-t border-slate-200 pt-10 lg:grid-cols-4">
            {HERO_METRICS.map((m) => (
              <StatCounter
                key={m.label}
                value={m.value}
                suffix={m.suffix}
                label={m.label}
                detail={m.detail}
                dark={false}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Brand Story Band (OBSIDIAN BLACK) */}
      <section className="about-story-section bg-obsidian-studio text-white py-20 lg:py-28 border-t border-white/10">
        <div className="about-story-block mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12 will-change-transform">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-16">
            <div className="about-story-left lg:col-span-7 space-y-6 will-change-transform">
              <p className="text-xs font-semibold tracking-widest text-[#F5A623] uppercase">
                Our Journey
              </p>
              <h2 className="font-display text-3xl sm:text-5xl font-bold tracking-tight leading-[1.08] text-white text-balance">
                Building visuals engineered for real commercial growth.
              </h2>
              <p className="text-base leading-relaxed text-white/70">
                We founded The XMarketeer with a clear mission: replace generic, template-driven marketing with bold, cinematic storytelling that commands attention and converts.
              </p>
              <p className="text-base leading-relaxed text-white/70">
                In a feed crowded with disposable posts, average creative fails. From short-form viral reels and high-fashion product spots to complete brand systems, we combine data-backed strategy, human narrative, and disciplined editing.
              </p>
            </div>

            <div className="about-story-right lg:col-span-5 will-change-transform">
              <StudioGlowCard tone="dark" tilt tiltStrength={8} className="hover-sheen flex items-center justify-center p-10">
                <img
                  src={BRAND_ASSETS.logoLight}
                  alt="The XMarketeer Brand Emblem"
                  referrerPolicy="no-referrer"
                  className="max-h-64 w-auto object-contain transition-transform duration-500 group-hover:scale-105"
                />
              </StudioGlowCard>
            </div>
          </div>
        </div>
      </section>

      {/* Core Team (SIGNATURE BRAND YELLOW) */}
      <section className="bg-yellow-studio text-[#0D0E11] py-20 lg:py-28 border-t border-black/10">
        <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#0D0E11] px-3.5 py-1 text-[11px] font-bold tracking-widest text-[#F5A623] uppercase">
              Leadership &amp; Craft
            </span>
            <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold tracking-tight text-[#0D0E11]">
              Meet the core creative unit
            </h2>
            <p className="mt-3 text-base font-medium text-[#0D0E11]/75">
              Directors, visual designers, and growth strategists dedicated to scaling partner brands.
            </p>
          </div>

          <div className="team-grid-wrap mt-12 grid grid-cols-1 gap-7 md:grid-cols-3">
            {TEAM_MEMBERS.map((member) => (
              <article key={member.role} className="team-card-anim will-change-transform">
                <StudioGlowCard tilt tiltStrength={7} className="hover-sheen h-full">
                  <div className="aspect-square overflow-hidden bg-slate-100">
                    <img
                      src={member.image}
                      alt={`${member.name} — ${member.role}`}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover object-top transition-transform duration-700 group-hover:scale-[1.04]"
                    />
                  </div>
                  <div className="p-6">
                    <p className="text-xs font-semibold text-[#D98A0B]">{member.role}</p>
                    <h3 className="mt-1 font-display text-xl font-bold text-slate-950 transition-colors duration-300 group-hover:text-[#B46900]">
                      {member.name}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-slate-600">{member.bio}</p>
                    <div
                      aria-hidden="true"
                      className="mt-4 h-[2px] w-full origin-left scale-x-0 rounded-full bg-gradient-to-r from-[#0D0E11] to-[#F5A623] transition-transform duration-500 ease-out group-hover:scale-x-100"
                    />
                  </div>
                </StudioGlowCard>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Partners (CRISP WHITE) */}
      <section className="bg-white-wash py-16 lg:py-20 border-t border-slate-200">
        <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
          <p className="mb-8 text-xs font-semibold tracking-widest text-slate-500 uppercase">
            Brands We&apos;ve Partnered With
          </p>
          <div className="grid grid-cols-3 gap-4 sm:grid-cols-5 lg:grid-cols-9">
            {PARTNER_LOGOS.map((partner) => (
              <div
                key={partner.name}
                className="group relative flex h-20 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-white p-3 shadow-xs transition-all duration-300 hover:-translate-y-1.5 hover:scale-105 hover:border-[#F5A623] hover:shadow-[0_14px_30px_-10px_rgba(245,166,35,0.28)]"
              >
                <img
                  src={partner.logo}
                  alt={partner.name}
                  referrerPolicy="no-referrer"
                  className="max-h-11 w-auto object-contain transition-transform duration-300 group-hover:-translate-y-1.5 group-hover:scale-95"
                />
                <span className="absolute inset-x-1 bottom-1 truncate rounded-md bg-slate-950 px-1.5 py-0.5 text-center text-[9px] font-semibold text-[#F5A623] opacity-0 translate-y-2 transition-all duration-250 group-hover:opacity-100 group-hover:translate-y-0">
                  {partner.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
