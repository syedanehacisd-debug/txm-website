import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowUpRight, Maximize2 } from 'lucide-react';
import {
  GRAPHIC_ASSETS,
  VIDEO_REELS,
  type GraphicAssetItem,
  type VideoReelItem,
} from '../data/agencyData';
import { MagneticButton } from '../components/MagneticButton';
import { InteractiveReelCard } from '../components/MarketingReelDeck';
import { StudioGlowCard } from '../components/StudioGlowCard';
import type { AppRoute } from '../components/Navbar';

gsap.registerPlugin(ScrollTrigger);

interface PortfolioPageProps {
  onNavigate: (route: AppRoute) => void;
  onSelectVideo: (reel: VideoReelItem) => void;
  onSelectGraphic: (asset: GraphicAssetItem) => void;
  initialFilter?: 'all' | 'video' | 'graphic';
}

export function PortfolioPage({
  onNavigate,
  onSelectVideo,
  onSelectGraphic,
  initialFilter = 'all',
}: PortfolioPageProps) {
  const [filter, setFilter] = useState<'all' | 'video' | 'graphic'>(initialFilter);
  const rootRef = useRef<HTMLDivElement>(null);
  const heroHeadRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setFilter(initialFilter);
  }, [initialFilter]);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      if (heroHeadRef.current) {
        gsap.to(heroHeadRef.current, {
          y: -36,
          opacity: 0.35,
          ease: 'none',
          force3D: true,
          scrollTrigger: {
            trigger: '.portfolio-hero-section',
            start: 'top top',
            end: 'bottom 25%',
            scrub: true,
          },
        });
      }

      gsap.from('.portfolio-card-anim', {
        y: 28,
        opacity: 0,
        stagger: 0.05,
        duration: 0.7,
        ease: 'expo.out',
        force3D: true,
        clearProps: 'transform',
      });

      const graphicCards = gsap.utils.toArray<HTMLElement>('.portfolio-graphic-scroll', root);
      graphicCards.forEach((card, idx) => {
        const fromLeft = idx % 2 === 0;
        gsap.fromTo(
          card,
          { x: fromLeft ? -64 : 64, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.85,
            ease: 'expo.out',
            force3D: true,
            clearProps: 'transform',
            scrollTrigger: {
              trigger: card,
              start: 'top 89%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      });
    }, root);

    return () => ctx.revert();
  }, [filter]);

  const showVideo = filter === 'all' || filter === 'video';
  const showGraphic = filter === 'all' || filter === 'graphic';

  return (
    <div ref={rootRef} className="overflow-x-clip bg-white text-slate-950">
      {/* Studio Header & Filter Controls */}
      <section className="portfolio-hero-section bg-studio-light text-slate-950 pt-32 pb-16 lg:pt-40 lg:pb-20 border-b border-slate-200 overflow-hidden">
        <div ref={heroHeadRef} className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12 will-change-transform">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/90 px-4 py-1.5 text-xs font-semibold tracking-wide text-slate-700 shadow-xs">
                <span className="h-2 w-2 rounded-full bg-[#F5A623]" />
                <span>Selected Works · Production Archive</span>
              </div>
              <h1 className="mt-4 font-display text-[clamp(2.4rem,4.8vw,4.1rem)] font-bold leading-[1.06] tracking-[-0.03em] text-slate-950 text-balance">
                Commercial reels &amp;{' '}
                <span className="bg-gradient-to-r from-[#D98A0B] via-[#F5A623] to-[#EA580C] bg-clip-text text-transparent">
                  visual systems
                </span>
              </h1>
              <p className="mt-4 max-w-xl text-base text-slate-600">
                Curated video productions, UGC campaigns, and graphic design collateral produced for partner brands.
              </p>
            </div>

            <div
              role="tablist"
              aria-label="Portfolio Categories"
              className="inline-flex items-center gap-1 self-start rounded-full border border-slate-200 bg-white p-1 shadow-xs"
            >
              {(
                [
                  { id: 'all', label: 'All Works' },
                  { id: 'video', label: 'Video Campaigns' },
                  { id: 'graphic', label: 'Graphic Design' },
                ] as const
              ).map((tab) => {
                const active = filter === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => setFilter(tab.id)}
                    className={`rounded-full px-4 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                      active
                        ? 'bg-slate-950 text-white shadow-sm'
                        : 'text-slate-600 hover:text-slate-950'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Video Campaigns Grid (OBSIDIAN BLACK) */}
      {showVideo && (
        <section className="bg-obsidian-studio text-white py-16 lg:py-20">
          <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
            <div className="mb-10 flex items-baseline justify-between border-b border-white/10 pb-4">
              <h2 className="font-display text-2xl font-bold tracking-tight text-white">
                01. Video Campaigns
              </h2>
              <span className="font-mono text-xs text-[#F5A623] tabular-nums">
                {VIDEO_REELS.length} Productions
              </span>
            </div>

            <div className="grid grid-cols-1 gap-7 sm:grid-cols-2 lg:grid-cols-3 [perspective:1400px]">
              {VIDEO_REELS.map((reel, idx) => (
                <div key={reel.id} className="portfolio-card-anim [transform-style:preserve-3d]">
                  <InteractiveReelCard
                    reel={reel}
                    index={idx}
                    onPlay={() => onSelectVideo(reel)}
                    layoutClassName="w-full"
                    aspectClassName="aspect-[9/14]"
                  />
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Graphic Design Grid (SIGNATURE BRAND YELLOW) */}
      {showGraphic && (
        <section id="graphics" className="bg-yellow-studio text-[#0D0E11] py-16 lg:py-24 border-t border-black/10">
          <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
            <div className="mb-10 flex items-baseline justify-between border-b border-black/15 pb-4">
              <h2 className="font-display text-2xl font-bold tracking-tight text-[#0D0E11]">
                02. Graphic Design &amp; Campaign Collateral
              </h2>
              <span className="inline-flex items-center rounded-full bg-[#0D0E11] px-3 py-1 font-mono text-xs font-semibold text-[#F5A623] tabular-nums">
                {GRAPHIC_ASSETS.length} Assets
              </span>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {GRAPHIC_ASSETS.map((asset) => (
                <article key={asset.id} className="portfolio-card-anim portfolio-graphic-scroll will-change-transform">
                  <StudioGlowCard
                    tilt
                    tiltStrength={7}
                    onClick={() => onSelectGraphic(asset)}
                    cursorText="VIEW"
                    className="hover-sheen h-full cursor-pointer"
                  >
                    <div className="relative aspect-[4/5] overflow-hidden bg-slate-100">
                      <img
                        src={asset.image}
                        alt={asset.alt}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-contain transition-transform duration-600 ease-out group-hover:scale-[1.04]"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                      <div className="absolute top-3 right-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-slate-900 shadow-sm opacity-0 scale-75 transition-all duration-300 group-hover:opacity-100 group-hover:scale-100 group-hover:bg-[#0D0E11] group-hover:text-[#F5A623]">
                        <Maximize2 className="h-4 w-4" />
                      </div>
                    </div>
                    <div className="px-5 py-4 border-t border-slate-100 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-[#D98A0B]">{asset.category}</p>
                        <h3 className="mt-1 font-display text-lg font-bold tracking-tight text-slate-950 transition-colors duration-300 group-hover:text-[#B46900] truncate">
                          {asset.title}
                        </h3>
                      </div>
                      <ArrowUpRight className="h-4 w-4 shrink-0 text-slate-400 transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-[#0D0E11]" />
                    </div>
                  </StudioGlowCard>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="bg-white-wash text-slate-950 py-20 px-5 sm:px-8 border-t border-slate-200">
        <div className="mx-auto max-w-3xl">
          <div className="studio-border-beam shadow-[0_24px_60px_-20px_rgba(15,23,42,0.12)]">
            <div className="rounded-[calc(1.75rem-1.5px)] bg-white p-10 sm:p-14 text-center">
              <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-950">
                Need dedicated creative production for your brand?
              </h2>
              <p className="mt-4 text-base text-slate-600">
                From one-off launch commercials to monthly creative retainers, let&apos;s build your next campaign.
              </p>
              <div className="mt-8 flex justify-center">
                <MagneticButton
                  onClick={() => onNavigate('/contact')}
                  cursorText="QUOTE"
                  className="inline-flex items-center gap-2 rounded-full bg-slate-950 px-7 py-3.5 text-sm font-semibold text-white shadow-md hover:bg-[#F5A623] hover:text-slate-950 transition-colors cursor-pointer"
                >
                  <span>Request Custom Quote</span>
                  <ArrowUpRight className="h-4 w-4" />
                </MagneticButton>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
