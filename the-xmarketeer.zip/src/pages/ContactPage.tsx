import { useEffect, useRef, useState, type FormEvent } from 'react';
import gsap from 'gsap';
import { ArrowRight, CheckCircle2, AlertCircle, Mail, MapPin, Phone } from 'lucide-react';
import { MagneticButton } from '../components/MagneticButton';
import { StudioGlowCard } from '../components/StudioGlowCard';

export function ContactPage() {
  const rootRef = useRef<HTMLDivElement>(null);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [brand, setBrand] = useState('');
  const [service, setService] = useState('');
  const [message, setMessage] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const root = rootRef.current;
    if (!root) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      gsap.from('.contact-anim', {
        y: 26,
        opacity: 0,
        stagger: 0.08,
        duration: 0.8,
        ease: 'power3.out',
        clearProps: 'transform',
      });
    }, root);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setStatus(null);

    if (name.trim().length < 2) {
      setStatus({ type: 'error', text: 'Please enter your full name (at least 2 characters).' });
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setStatus({ type: 'error', text: 'Please enter a valid email address.' });
      return;
    }

    if (phone.trim() && !/^[0-9+\-\s()]{7,24}$/.test(phone.trim())) {
      setStatus({ type: 'error', text: 'Please enter a valid phone number.' });
      return;
    }

    if (message.trim().length < 15) {
      setStatus({
        type: 'error',
        text: 'Please describe your project goals in at least 15 characters.',
      });
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone, brand, service, message }),
      });

      const data = (await response.json()) as { success?: boolean; message?: string; error?: string };

      if (!response.ok || !data.success) {
        setStatus({
          type: 'error',
          text: data.error || 'Unable to submit your inquiry right now. Please try again.',
        });
      } else {
        setStatus({
          type: 'success',
          text:
            data.message ||
            'Inquiry received! Our creative director will reach out within 24 hours.',
        });
        setName('');
        setEmail('');
        setPhone('');
        setBrand('');
        setService('');
        setMessage('');
      }
    } catch {
      setStatus({
        type: 'error',
        text: 'Network error while sending inquiry. Please email thexmarketeer@gmail.com directly.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div ref={rootRef} className="bg-studio-light text-slate-950 pt-32 pb-24 lg:pt-40 overflow-x-clip">
      <div className="mx-auto max-w-[1380px] px-5 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16 items-start">
          {/* Left Column: Direct Details */}
          <div className="lg:col-span-5 space-y-8">
            <div className="contact-anim">
              <div className="inline-flex items-center gap-2 rounded-full border border-slate-200/90 bg-white/90 px-4 py-1.5 text-xs font-semibold tracking-wide text-slate-700 shadow-xs">
                <span className="h-2 w-2 rounded-full bg-[#F5A623] animate-pulse" />
                <span>Start Your Project · 24h Response</span>
              </div>
              <h1 className="mt-4 font-display text-[clamp(2.4rem,4.5vw,3.8rem)] font-bold leading-[1.06] tracking-[-0.03em] text-slate-950 text-balance">
                Ready to{' '}
                <span className="bg-gradient-to-r from-[#D98A0B] via-[#F5A623] to-[#EA580C] bg-clip-text text-transparent">
                  scale your brand?
                </span>
              </h1>
              <p className="mt-4 text-base leading-relaxed text-slate-600">
                We help modern businesses grow with commercial video production, performance creatives, social media strategy, and brand storytelling.
              </p>
            </div>

            <div className="contact-anim space-y-4">
              <a
                href="mailto:thexmarketeer@gmail.com"
                className="group flex items-center gap-4 rounded-2xl border border-black/10 bg-[#0D0E11] p-5 text-white shadow-md transition-all duration-300 hover:-translate-y-1 hover:border-[#F5A623] hover:shadow-[0_18px_38px_-12px_rgba(245,166,35,0.3)]"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#F5A623] text-[#0D0E11] transition-transform duration-300 group-hover:scale-110">
                  <Mail className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs font-medium text-white/55">Email</p>
                  <p className="text-sm font-semibold text-white group-hover:text-[#F5A623] transition-colors">
                    thexmarketeer@gmail.com
                  </p>
                </div>
              </a>

              <a
                href="tel:+923422578815"
                className="group flex items-center gap-4 rounded-2xl border border-black/10 bg-[#0D0E11] p-5 text-white shadow-md transition-all duration-300 hover:-translate-y-1 hover:border-[#F5A623] hover:shadow-[0_18px_38px_-12px_rgba(245,166,35,0.3)]"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#F5A623] text-[#0D0E11] transition-transform duration-300 group-hover:scale-110">
                  <Phone className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs font-medium text-white/55">Phone</p>
                  <p className="text-sm font-semibold text-white tabular-nums group-hover:text-[#F5A623] transition-colors">
                    +92 342 2578815
                  </p>
                </div>
              </a>

              <div className="group flex items-center gap-4 rounded-2xl border border-black/10 bg-[#0D0E11] p-5 text-white shadow-md transition-all duration-300 hover:-translate-y-1 hover:border-[#F5A623]">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#F5A623] text-[#0D0E11] transition-transform duration-300 group-hover:scale-110">
                  <MapPin className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-xs font-medium text-white/55">Studio Location</p>
                  <p className="text-sm font-semibold text-white">Karachi, Pakistan</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Validated Inquiry Form */}
          <div className="contact-anim lg:col-span-7">
            <div className="studio-border-beam shadow-[0_24px_70px_-20px_rgba(15,23,42,0.14)]">
              <StudioGlowCard className="p-6 sm:p-10 text-slate-900 border-0 shadow-none">
                <div className="mb-8">
                  <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-950">
                    Tell us about your campaign
                  </h2>
                  <p className="mt-2 text-sm text-slate-600">
                    Complete the brief below and our creative team will follow up within 24 hours.
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5" noValidate>
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <label htmlFor="contact-name" className="block text-xs font-semibold text-slate-700">
                        Your Name *
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Ayesha Khan"
                        className="w-full rounded-xl border border-slate-200 bg-slate-50/75 px-4 py-3 text-sm text-slate-950 placeholder:text-slate-400 focus:border-[#F5A623] focus:bg-white focus:outline-none transition-colors"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label htmlFor="contact-email" className="block text-xs font-semibold text-slate-700">
                        Email Address *
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="ayesha@brand.com"
                        className="w-full rounded-xl border border-slate-200 bg-slate-50/75 px-4 py-3 text-sm text-slate-950 placeholder:text-slate-400 focus:border-[#F5A623] focus:bg-white focus:outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <label htmlFor="contact-phone" className="block text-xs font-semibold text-slate-700">
                        Phone Number *
                      </label>
                      <input
                        id="contact-phone"
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+92 300 1234567"
                        className="w-full rounded-xl border border-slate-200 bg-slate-50/75 px-4 py-3 text-sm text-slate-950 placeholder:text-slate-400 focus:border-[#F5A623] focus:bg-white focus:outline-none transition-colors"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label htmlFor="contact-brand" className="block text-xs font-semibold text-slate-700">
                        Brand / Company Name *
                      </label>
                      <input
                        id="contact-brand"
                        type="text"
                        required
                        value={brand}
                        onChange={(e) => setBrand(e.target.value)}
                        placeholder="Sattis Studio"
                        className="w-full rounded-xl border border-slate-200 bg-slate-50/75 px-4 py-3 text-sm text-slate-950 placeholder:text-slate-400 focus:border-[#F5A623] focus:bg-white focus:outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="contact-service" className="block text-xs font-semibold text-slate-700">
                      Service Required *
                    </label>
                    <select
                      id="contact-service"
                      required
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50/75 px-4 py-3 text-sm text-slate-950 focus:border-[#F5A623] focus:bg-white focus:outline-none transition-colors"
                    >
                      <option value="" disabled>
                        Select a service
                      </option>
                      <option value="Video Production">Video Production (Commercials &amp; Reels)</option>
                      <option value="Graphic Designing">Graphic Designing &amp; Visual Identity</option>
                      <option value="Content Writing">Content Writing &amp; Ad Copywriting</option>
                      <option value="Social Media Marketing">Social Media Marketing &amp; Paid Growth</option>
                      <option value="Full Creative Retainer">Full Agency Creative Retainer</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label htmlFor="contact-message" className="block text-xs font-semibold text-slate-700">
                      Project Goals &amp; Timeline *
                    </label>
                    <textarea
                      id="contact-message"
                      required
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Share your goals, deliverables needed, and target launch window..."
                      className="w-full rounded-xl border border-slate-200 bg-slate-50/75 px-4 py-3 text-sm text-slate-950 placeholder:text-slate-400 focus:border-[#F5A623] focus:bg-white focus:outline-none resize-y transition-colors"
                    />
                  </div>

                  {status && (
                    <div
                      role="alert"
                      className={`flex items-start gap-2.5 rounded-xl border p-4 text-sm font-medium ${
                        status.type === 'success'
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                          : 'border-red-200 bg-red-50 text-red-900'
                      }`}
                    >
                      {status.type === 'success' ? (
                        <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600 mt-0.5" />
                      ) : (
                        <AlertCircle className="h-5 w-5 shrink-0 text-red-600 mt-0.5" />
                      )}
                      <span>{status.text}</span>
                    </div>
                  )}

                  <MagneticButton
                    type="submit"
                    disabled={submitting}
                    cursorText="SEND"
                    className="flex w-full items-center justify-center gap-2 rounded-full bg-slate-950 py-3.5 text-sm font-semibold text-white shadow-md transition-colors hover:bg-[#F5A623] hover:text-slate-950 disabled:opacity-60 cursor-pointer"
                  >
                    <span>{submitting ? 'Sending Inquiry...' : 'Send Project Inquiry'}</span>
                    {!submitting && <ArrowRight className="h-4 w-4" />}
                  </MagneticButton>
                </form>
              </StudioGlowCard>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
