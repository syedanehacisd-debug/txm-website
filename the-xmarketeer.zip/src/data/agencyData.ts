export interface MetricItem {
  value: number;
  suffix: string;
  label: string;
  detail: string;
}

export interface CapabilityItem {
  id: string;
  index: string;
  category: string;
  title: string;
  summary: string;
  description: string;
  image: string;
  features: string[];
  ctaLabel: string;
  ctaTarget: '/portfolio' | '/contact';
  ctaHash?: string;
}

export interface VideoReelItem {
  id: string;
  title: string;
  client: string;
  category: string;
  poster: string;
  videoUrl: string;
  description: string;
}

export interface GraphicAssetItem {
  id: string;
  title: string;
  category: string;
  image: string;
  alt: string;
}

export interface PartnerLogoItem {
  name: string;
  logo: string;
}

export interface TeamMemberItem {
  name: string;
  role: string;
  bio: string;
  image: string;
}

export interface ProcessStepItem {
  step: string;
  title: string;
  description: string;
}

export const BRAND_ASSETS = {
  logoDark: '/assets/aistudio/logo-removebg-preview_b20891fd_b20891fd.png',
  logoLight: '/assets/aistudio/convert_the_color_of_text_202605231604-removebg-preview_8f4a6ab8_8f4a6ab8.png',
  favicon: '/assets/aistudio/cb14d1ad-a729-4c9b-949f-dff8970ef147_removalai_preview_141e5480_141e5480.png',
  studioHero: '/assets/aistudio/remove_he_tittle_202605211318_31a559fb_31a559fb.jpeg',
  sampleReelVideo: 'https://cdn.shopify.com/videos/c/o/v/ac9a98edeed541019165e404ed99594e.mp4',
};

export const HERO_METRICS: MetricItem[] = [
  { value: 150, suffix: '+', label: 'Productions Shipped', detail: 'Commercial films & reels' },
  { value: 50, suffix: '+', label: 'Partner Brands', detail: 'D2C & enterprise growth' },
  { value: 5, suffix: 'M+', label: 'Organic & Paid Reach', detail: 'Across Meta & TikTok' },
  { value: 100, suffix: '%', label: 'In-House Direction', detail: 'Concept through delivery' },
];

export const CAPABILITIES: CapabilityItem[] = [
  {
    id: 'video-production',
    index: '01',
    category: 'Production',
    title: 'Video Production & Creative Direction',
    summary: '4K commercials, product cinematography, and conversion-focused vertical reels.',
    description:
      'From broadcast-grade brand films to high-retention TikTok and Instagram Reels, our in-house crew leads scripting, set direction, lighting, filming, sound design, and color grading.',
    image: '/assets/aistudio/Video-Production_da18da72_da18da72.jpg',
    features: [
      '4K Commercial Films',
      'Direct-Response UGC Reels',
      'Product Cinematography',
      'Sound Design & Color Grading',
    ],
    ctaLabel: 'View Video Reels',
    ctaTarget: '/portfolio',
  },
  {
    id: 'graphic-design',
    index: '02',
    category: 'Design & Identity',
    title: 'Graphic Designing & Visual Identity',
    summary: 'Brand systems, scroll-stopping paid creatives, and cohesive campaign art direction.',
    description:
      'We build unmistakable visual identities, static and carousel ad creative variations, packaging collateral, and editorial design systems engineered to elevate click-through performance.',
    image: '/assets/aistudio/I_WANT_graphic_production_202605231540_4f0c93f9_4f0c93f9.jpeg',
    features: [
      'Visual Identity & Brand Guides',
      'Paid Social Static & Carousels',
      'Campaign Onboarding Suites',
      'Packaging & Print Collateral',
    ],
    ctaLabel: 'View Design Works',
    ctaTarget: '/portfolio',
    ctaHash: 'graphics',
  },
  {
    id: 'content-writing',
    index: '03',
    category: 'Storytelling',
    title: 'Content Writing & Ad Copywriting',
    summary: 'Sharp positioning, video hook scripts, and landing copy that converts attention.',
    description:
      'Words engineered for clarity and commercial persuasion. We craft video scripts, direct-response ad hooks, landing page messaging, and retention email flows grounded in buyer psychology.',
    image: '/assets/aistudio/i_want_this_type_of_202605231650_a6e1173a_a6e1173a.jpeg',
    features: [
      'Direct-Response Ad Copy',
      'Short-Form Video Scripting',
      'Brand Positioning & Voice',
      'Conversion Email Sequences',
    ],
    ctaLabel: 'Request Copy Strategy',
    ctaTarget: '/contact',
  },
  {
    id: 'social-media',
    index: '04',
    category: 'Growth Marketing',
    title: 'Social Media Marketing & Paid Growth',
    summary: 'Full-funnel paid media execution across Meta, TikTok, YouTube, and LinkedIn.',
    description:
      'Data-backed campaign management and creative testing frameworks built to scale return on ad spend (ROAS), lower acquisition cost, and compound organic audience equity.',
    image: '/assets/aistudio/make_a_image_like_this_202605231655_2d039307_2d039307.jpeg',
    features: [
      'Meta & TikTok Paid Media',
      'Multivariate Creative Testing',
      'Creator & UGC Orchestration',
      'Weekly Attribution & Reporting',
    ],
    ctaLabel: 'Scale Your Campaigns',
    ctaTarget: '/contact',
  },
];

export const VIDEO_REELS: VideoReelItem[] = [
  {
    id: 'sattis',
    title: 'Sattis Signature Launch',
    client: 'Sattis',
    category: 'E-Commerce Reel',
    poster: '/assets/aistudio/make_it_in_this_size_202605071340_659449f6_659449f6.jpeg',
    videoUrl: BRAND_ASSETS.sampleReelVideo,
    description:
      'Luxury product storytelling pairing controlled warm lighting, rhythmic sound cues, and sharp editorial pacing.',
  },
  {
    id: 'otn-h3',
    title: 'OTN Commercial',
    client: 'H3 Technologies',
    category: 'Commercial Film',
    poster: '/assets/aistudio/OTN_0c284051_0c284051.jpeg',
    videoUrl: BRAND_ASSETS.sampleReelVideo,
    description:
      'Brand technology showcase balancing clean architectural framing with modern workplace narrative.',
  },
  {
    id: 'kyc-dispatch',
    title: 'KYC Dispatch Campaign',
    client: 'KYC Logistics',
    category: 'Performance UGC',
    poster: '/assets/aistudio/DATED_VERSION_OF__37__e6d70889_e6d70889.jpg',
    videoUrl: BRAND_ASSETS.sampleReelVideo,
    description:
      'High-velocity fulfillment story engineered to communicate operational scale and delivery reliability.',
  },
  {
    id: 'kkm-sweets',
    title: 'KKM Sweets & Nimco',
    client: 'KKM Heritage',
    category: 'Food & Lifestyle',
    poster: '/assets/aistudio/DATED_VERSION_OF__32__d990d5e1_d990d5e1.jpg',
    videoUrl: BRAND_ASSETS.sampleReelVideo,
    description:
      'Artisanal culinary film celebrating heritage flavor, rich textures, and authentic hospitality.',
  },
  {
    id: 'al-rifaf',
    title: 'Signature by Al Rifaf',
    client: 'Al Rifaf',
    category: 'Luxury Fragrance',
    poster: '/assets/aistudio/make_it_in_this_size_202605071340__1__3853cb98_3853cb98.jpeg',
    videoUrl: BRAND_ASSETS.sampleReelVideo,
    description:
      'Editorial fragrance spot highlighting sculptural silhouettes, gold accents, and charismatic presence.',
  },
  {
    id: 'txm-bts',
    title: 'TXM Studio Production',
    client: 'The XMarketeer',
    category: 'Behind the Scenes',
    poster: '/assets/aistudio/remove_he_tittle_202605211318_31a559fb_31a559fb.jpeg',
    videoUrl: BRAND_ASSETS.sampleReelVideo,
    description:
      'Inside our multi-camera commercial studio workflow, softbox lighting rigs, and real-time color grading.',
  },
];

export const GRAPHIC_ASSETS: GraphicAssetItem[] = [
  {
    id: 'g-sattis',
    title: 'Welcome Aboard — Sattis',
    category: 'Partner Onboarding',
    image: '/assets/aistudio/Untitled_design__19__196c4591_196c4591.jpg',
    alt: 'Welcome Aboard Sattis partnership creative',
  },
  {
    id: 'g-momentum',
    title: 'Keep Momentum & Scale Faster',
    category: 'Paid Social Creative',
    image: '/assets/aistudio/2_5c4a2096_5c4a2096.jpg',
    alt: 'Keep Momentum and Scale Faster ad creative',
  },
  {
    id: 'g-growth',
    title: 'Frustrated With Slow Growth?',
    category: 'Direct Response Hook',
    image: '/assets/aistudio/1_6d46216f_6d46216f.jpg',
    alt: 'Frustrated with slow business growth ad hook',
  },
  {
    id: 'g-tba',
    title: 'Welcome Aboard — TBA',
    category: 'Partner Onboarding',
    image: '/assets/aistudio/Untitled_design__20__438589c9_438589c9.jpg',
    alt: 'Welcome Aboard TBA partnership creative',
  },
  {
    id: 'g-trainingsx',
    title: 'Welcome Aboard — TrainingsX',
    category: 'EdTech Launch',
    image: '/assets/aistudio/Untitled_design__21__8f6e22bc_8f6e22bc.jpg',
    alt: 'Welcome Aboard TrainingsX launch creative',
  },
  {
    id: 'g-starwaves',
    title: 'Welcome Aboard — Star Waves',
    category: 'Corporate Direction',
    image: '/assets/aistudio/Untitled_design__22__fa038851_fa038851.jpg',
    alt: 'Welcome Aboard Star Waves Enterprises creative',
  },
  {
    id: 'g-kii',
    title: 'Welcome Aboard — KII Steel',
    category: 'Industrial Branding',
    image: '/assets/aistudio/Untitled_design__23__e7c445f3_e7c445f3.jpg',
    alt: 'Welcome Aboard KII Steel Engineering creative',
  },
  {
    id: 'g-process',
    title: '4-Steps Project Process',
    category: 'Editorial Infographic',
    image: '/assets/aistudio/Add_a_heading__4__23c1b6be_23c1b6be.jpg',
    alt: 'The XMarketeer 4-Steps Project Process visual',
  },
  {
    id: 'g-zfoil',
    title: 'Welcome Aboard — Z Foil Sheets',
    category: 'Brand Collaboration',
    image: '/assets/aistudio/Untitled_design__24__7f2f188e_7f2f188e.jpg',
    alt: 'Welcome Aboard Z Foil Sheets creative',
  },
  {
    id: 'g-ouj',
    title: 'Welcome Aboard — OUJ Parlour',
    category: 'Beauty & Wellness',
    image: '/assets/aistudio/Untitled_design__25__c1359e2f_c1359e2f.jpg',
    alt: 'Welcome Aboard OUJ Beauty Parlour creative',
  },
  {
    id: 'g-kkm',
    title: 'Welcome Aboard — KKM',
    category: 'Heritage Retail',
    image: '/assets/aistudio/3_c1841807_c1841807.jpg',
    alt: 'Welcome Aboard KKM Sweets and Nimco creative',
  },
  {
    id: 'g-kandhoi',
    title: 'KKM Kandhoi Campaign Key Visual',
    category: 'Campaign Poster',
    image: '/assets/aistudio/DATED_VERSION_OF__32__d990d5e1_d990d5e1.jpg',
    alt: 'KKM Kandhoi campaign key visual',
  },
];

export const PARTNER_LOGOS: PartnerLogoItem[] = [
  { name: 'Sattis', logo: '/assets/aistudio/sattis_a0063051_a0063051.png' },
  { name: 'H3 Technologies', logo: '/assets/aistudio/h3_d135a922_d135a922.png' },
  { name: 'TBA', logo: '/assets/aistudio/TBA_08056272_08056272.png' },
  { name: 'TrainingsX', logo: '/assets/aistudio/tx_721e390d_721e390d.png' },
  { name: 'Star Waves', logo: '/assets/aistudio/Starwaves_bfc3eb62_bfc3eb62.png' },
  { name: 'KII Steel Engineering', logo: '/assets/aistudio/steel_99b38251_99b38251.jpg' },
  { name: 'Al Rifaf', logo: '/assets/aistudio/alrifaf_7eba2afe_7eba2afe.png' },
  { name: 'OUJ Beauty Parlour', logo: '/assets/aistudio/ouj_905dbf38_905dbf38.png' },
  { name: 'Z Foil Sheets', logo: '/assets/aistudio/zfoil_ffa8cc45_ffa8cc45.png' },
];

export const TEAM_MEMBERS: TeamMemberItem[] = [
  {
    name: 'Agency Leadership',
    role: 'Founder & Strategic Lead',
    bio: 'Leads performance growth architecture, D2C brand positioning, and executive client partnerships.',
    image: '/assets/aistudio/1716278255956_7fa06a9c_7fa06a9c.jpg',
  },
  {
    name: 'Creative Director',
    role: 'Cinematography & Brand Vision',
    bio: 'Directs studio productions, lighting architecture, visual systems, and commercial set execution.',
    image: '/assets/aistudio/make_the_background_this_grey_202605231715_aa684b8b_aa684b8b.jpeg',
  },
  {
    name: 'Lead Visual Editor',
    role: 'Post-Production & Motion',
    bio: 'Shapes rhythmic cut structure, sound design, color grading, and kinetic motion systems.',
    image: '/assets/aistudio/use_this_greyas_background_2K_202605231753_dd5369a6_dd5369a6.jpeg',
  },
];

export const PROCESS_STEPS: ProcessStepItem[] = [
  {
    step: '01',
    title: 'Strategy & Planning',
    description:
      'We audit your brand DNA, audience psychology, and competitive landscape to architect a clear creative roadmap.',
  },
  {
    step: '02',
    title: 'Video Production',
    description:
      'In-house set design, multi-cam lighting, commercial direction, and creator-led UGC filming.',
  },
  {
    step: '03',
    title: 'Editing & Graphics',
    description:
      'Rhythmic pacing, bespoke sound design, color grading, and high-contrast static ad variations.',
  },
  {
    step: '04',
    title: 'Ads Campaigns',
    description:
      'Structured channel deployment across Meta and TikTok with weekly creative iteration to scale ROAS.',
  },
];
