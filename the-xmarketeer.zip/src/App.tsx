import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CustomCursor } from './components/CustomCursor';
import { Footer } from './components/Footer';
import { GraphicLightbox, VideoModal } from './components/Modals';
import { Navbar, type AppRoute } from './components/Navbar';
import type { GraphicAssetItem, VideoReelItem } from './data/agencyData';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { HomePage } from './pages/HomePage';
import { PortfolioPage } from './pages/PortfolioPage';
import { ServicesPage } from './pages/ServicesPage';

gsap.registerPlugin(ScrollTrigger);

function normalizeRoute(pathname: string): AppRoute {
  const clean = pathname.toLowerCase();
  if (clean.includes('services')) return '/services';
  if (clean.includes('portfolio')) return '/portfolio';
  if (clean.includes('about')) return '/about';
  if (clean.includes('contact')) return '/contact';
  return '/';
}

function forceScrollTop() {
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  document.documentElement.scrollTop = 0;
  document.body.scrollTop = 0;
}

export default function App() {
  const [route, setRoute] = useState<AppRoute>(() => normalizeRoute(window.location.pathname));
  const [portfolioFilter, setPortfolioFilter] = useState<'all' | 'video' | 'graphic'>(() =>
    window.location.hash === '#graphics' ? 'graphic' : 'all'
  );
  const [selectedVideo, setSelectedVideo] = useState<VideoReelItem | null>(null);
  const [selectedGraphic, setSelectedGraphic] = useState<GraphicAssetItem | null>(null);

  const pageContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if ('scrollRestoration' in window.history) {
      window.history.scrollRestoration = 'manual';
    }
    const handlePopState = () => {
      forceScrollTop();
      setRoute(normalizeRoute(window.location.pathname));
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleNavigate = (targetRoute: AppRoute, hash?: string) => {
    const sameRoute = targetRoute === route;

    if (targetRoute === '/portfolio' && hash === 'graphics') {
      setPortfolioFilter('graphic');
    } else if (targetRoute === '/portfolio') {
      setPortfolioFilter('all');
    }

    const nextUrl = hash ? `${targetRoute}#${hash}` : targetRoute;
    if (window.location.pathname + window.location.hash !== nextUrl) {
      window.history.pushState({}, '', nextUrl);
    }

    if (sameRoute && hash) {
      const el = document.getElementById(hash);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
    }

    // Reset scroll position immediately before unmounting pinned sections & mounting next page
    forceScrollTop();
    setRoute(targetRoute);
  };

  // Run before paint and before child ScrollTrigger useEffects so every new page starts at its Hero (y = 0)
  useLayoutEffect(() => {
    forceScrollTop();
    const rafId = requestAnimationFrame(() => {
      forceScrollTop();
      ScrollTrigger.refresh();
    });
    return () => cancelAnimationFrame(rafId);
  }, [route]);

  useEffect(() => {
    const el = pageContainerRef.current;
    if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        el,
        { opacity: 0 },
        { opacity: 1, duration: 0.35, ease: 'power2.out', clearProps: 'opacity' }
      );
    }, el);

    return () => {
      ctx.revert();
    };
  }, [route]);

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-950">
      <CustomCursor />
      <Navbar currentRoute={route} onNavigate={handleNavigate} />

      <main ref={pageContainerRef} className="flex-1">
        {route === '/' && (
          <HomePage
            onNavigate={handleNavigate}
            onSelectVideo={setSelectedVideo}
            onSelectGraphic={setSelectedGraphic}
          />
        )}
        {route === '/services' && <ServicesPage onNavigate={handleNavigate} />}
        {route === '/portfolio' && (
          <PortfolioPage
            onNavigate={handleNavigate}
            onSelectVideo={setSelectedVideo}
            onSelectGraphic={setSelectedGraphic}
            initialFilter={portfolioFilter}
          />
        )}
        {route === '/about' && <AboutPage onNavigate={handleNavigate} />}
        {route === '/contact' && <ContactPage />}
      </main>

      <Footer onNavigate={handleNavigate} />

      <VideoModal reel={selectedVideo} onClose={() => setSelectedVideo(null)} />
      <GraphicLightbox asset={selectedGraphic} onClose={() => setSelectedGraphic(null)} />
    </div>
  );
}
