import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ContactInquiryBody {
  name?: string;
  email?: string;
  phone?: string;
  brand?: string;
  service?: string;
  message?: string;
}

const NAME_REGEX = /^[a-zA-Z\s.'-]{2,60}$/;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[0-9+\-\s()]{7,24}$/;

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT || 3000);
  const isProd = process.env.NODE_ENV === 'production';

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', service: 'the-xmarketeer-server', timestamp: new Date().toISOString() });
  });

  app.post('/api/contact', async (req: Request, res: Response) => {
    const body = (req.body || {}) as ContactInquiryBody;
    const name = (body.name || '').trim();
    const email = (body.email || '').trim();
    const phone = (body.phone || '').trim();
    const brand = (body.brand || '').trim();
    const service = (body.service || '').trim();
    const message = (body.message || '').trim();

    if (!NAME_REGEX.test(name)) {
      res.status(400).json({ success: false, error: 'Please enter a valid full name (at least 2 letters).' });
      return;
    }

    if (!EMAIL_REGEX.test(email)) {
      res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
      return;
    }

    if (phone && !PHONE_REGEX.test(phone)) {
      res.status(400).json({ success: false, error: 'Please enter a valid phone number.' });
      return;
    }

    if (!brand || brand.length < 2) {
      res.status(400).json({ success: false, error: 'Please provide your brand or company name.' });
      return;
    }

    if (!service) {
      res.status(400).json({ success: false, error: 'Please select a service.' });
      return;
    }

    if (message.length < 15) {
      res.status(400).json({ success: false, error: 'Please describe your project in at least 15 characters.' });
      return;
    }

    const inquiryId = `TXM-${Date.now().toString(36).toUpperCase()}`;

    // Forward to Web3Forms if configured in environment, without exposing keys client-side
    const web3FormsKey = process.env.WEB3FORMS_ACCESS_KEY;
    if (web3FormsKey) {
      try {
        await fetch('https://api.web3forms.com/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify({
            access_key: web3FormsKey,
            subject: `New Project Inquiry (${inquiryId}) — ${brand}`,
            name,
            email,
            phone,
            brand,
            service,
            message,
          }),
        });
      } catch {
        // Non-blocking external relay
      }
    }

    res.status(200).json({
      success: true,
      inquiryId,
      message: `Thank you, ${name}. Your inquiry (${inquiryId}) has been received—our creative director will respond within 24 hours.`,
    });
  });

  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir, { index: false }));
    app.get('*', (_req: Request, res: Response) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`The XMarketeer server running on http://0.0.0.0:${port}`);
  });
}

startServer();
