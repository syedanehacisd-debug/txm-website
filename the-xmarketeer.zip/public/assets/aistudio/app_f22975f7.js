/**
 * The XMarketeer — Agency Master Application Script
 * Dynamic island navigation, interactive video popup modal,
 * GSAP ScrollTrigger reveals, typing effect, Swiper carousel, and form validation.
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. DYNAMIC ISLAND & FLOATING NAVBAR
  initDynamicIsland();
  initMobileMenu();
  initUgcViewportPlayback();
  initScrollNav();

  // 2. HERO TYPING EFFECT
  initTypingEffect();

  // 3. UGC & PORTFOLIO VIDEO MODAL + HOVER PLAY
  initVideoInteractions();

  // 4. GSAP & SCROLL TRIGGER ANIMATIONS
  initGsapAnimations();
  initUgcScrollShowcase();

  // 5. SWIPER CAPABILITIES CAROUSEL
  initSwiperCarousel();

  // 6. PORTFOLIO FILTER & GRAPHIC LIGHTBOX
  initPortfolioInteractions();

  // 7. CONTACT FORM VALIDATION & SUBMISSION
  initContactForm();

  // 8. STATS COUNTERS
  initStatsCounter();
});

/* ==========================================================================
   1. Dynamic Island & Navigation
   ========================================================================== */
function initDynamicIsland() {
  const nav = document.getElementById('nav-links');
  const island = document.getElementById('island');
  const items = document.querySelectorAll('.nav-links li:not(.logo-link) a');
  const logoLink = document.querySelector('.nav-links .logo-link a');
  const activeLink = document.querySelector('.nav-links a.active-link');

  if (!nav || !island || items.length === 0) return;

  function moveIsland(element) {
    if (!element) return;
    const rect = element.getBoundingClientRect();
    const parentRect = nav.getBoundingClientRect();

    island.style.left = `${rect.left - parentRect.left}px`;
    island.style.width = `${rect.width}px`;
    island.style.height = `${rect.height}px`;
    island.style.opacity = '1';

    items.forEach(i => i.classList.remove('active-item'));
    element.classList.add('active-item');
  }

  function resetIsland() {
    if (activeLink && window.innerWidth > 768) {
      moveIsland(activeLink);
    } else {
      island.style.opacity = '0';
      items.forEach(i => i.classList.remove('active-item'));
    }
  }

  items.forEach(item => {
    item.addEventListener('mouseenter', () => {
      if (window.innerWidth > 768) {
        moveIsland(item);
      }
    });
  });

  // Logo gets its own lift effect (CSS) - the dark island must not jump onto it
  if (logoLink) {
    logoLink.addEventListener('mouseenter', () => {
      if (window.innerWidth > 768) resetIsland();
    });
  }

  nav.addEventListener('mouseleave', () => {
    if (window.innerWidth > 768) {
      resetIsland();
    }
  });

  // Initial set
  setTimeout(() => {
    if (activeLink && window.innerWidth > 768) {
      moveIsland(activeLink);
    }
  }, 200);

  window.addEventListener('resize', () => {
    if (window.innerWidth <= 768) {
      island.style.opacity = '0';
    } else {
      resetIsland();
    }
  });
}

function initMobileMenu() {
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('nav-links');

  if (!hamburger || !navLinks) return;

  hamburger.addEventListener('click', (e) => {
    e.stopPropagation();
    hamburger.classList.toggle('active');
    navLinks.classList.toggle('active');
    document.body.style.overflow = navLinks.classList.contains('active') ? 'hidden' : '';
  });

  // Close when clicking nav link
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      hamburger.classList.remove('active');
      navLinks.classList.remove('active');
      document.body.style.overflow = '';
    });
  });

  // Close on outside click
  document.addEventListener('click', (e) => {
    if (navLinks.classList.contains('active') && !navLinks.contains(e.target) && !hamburger.contains(e.target)) {
      hamburger.classList.remove('active');
      navLinks.classList.remove('active');
      document.body.style.overflow = '';
    }
  });

  // Close on ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && navLinks.classList.contains('active')) {
      hamburger.classList.remove('active');
      navLinks.classList.remove('active');
      document.body.style.overflow = '';
    }
  });
}

function initScrollNav() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });
}

/* ==========================================================================
   2. Typing Effect (Hero Headline)
   ========================================================================== */
function initTypingEffect() {
  const textElement = document.querySelector('.typing-text');
  if (!textElement) return;

  const phrases = [
    'Video Production',
    'Viral UGC Creatives',
    'Performance Marketing',
    'Graphic Designing',
    'Brand Storytelling'
  ];

  let phraseIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  const typeSpeed = 90;
  const deleteSpeed = 45;
  const holdDelay = 1800;

  function type() {
    const currentPhrase = phrases[phraseIndex];

    if (isDeleting) {
      textElement.textContent = currentPhrase.substring(0, charIndex - 1);
      charIndex--;
    } else {
      textElement.textContent = currentPhrase.substring(0, charIndex + 1);
      charIndex++;
    }

    let delay = isDeleting ? deleteSpeed : typeSpeed;

    if (!isDeleting && charIndex === currentPhrase.length) {
      delay = holdDelay;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      phraseIndex = (phraseIndex + 1) % phrases.length;
      delay = 350;
    }

    setTimeout(type, delay);
  }

  setTimeout(type, 600);
}

/* ==========================================================================
   3. UGC Video & Portfolio Interactions
   ========================================================================== */
function initVideoInteractions() {
  const popup = document.querySelector('.popUpForVideo');
  const popupVideo = popup ? popup.querySelector('video') : null;
  const closeBtn = document.querySelector('.close-popup');

  // Hover to play / pause video cards
  const videoCards = document.querySelectorAll('.video-thumbnail, .ugc-item video, .video-player-wrap video');

  videoCards.forEach(video => {
    video.addEventListener('mouseenter', () => {
      try {
        const playPromise = video.play();
        if (playPromise !== undefined) {
          playPromise.catch(() => {});
        }
      } catch (err) {}
    });

    video.addEventListener('mouseleave', () => {
      try {
        video.pause();
        // Do not force reset if video controls are visible
        if (!video.hasAttribute('controls')) {
          video.currentTime = 0;
        }
      } catch (err) {}
    });
  });

  // Modal open triggers
  const ugcItems = document.querySelectorAll('.ugc-item, .video-expand-btn');

  ugcItems.forEach(item => {
    item.addEventListener('click', function (e) {
      e.preventDefault();
      if (!popup || !popupVideo) return;

      let videoSrc = '';
      if (this.classList.contains('video-expand-btn')) {
        const parentCard = this.closest('.video-card');
        const source = parentCard ? parentCard.querySelector('video source') : null;
        if (source) videoSrc = source.getAttribute('src');
      } else {
        const source = this.querySelector('video source');
        if (source) videoSrc = source.getAttribute('src');
      }

      if (videoSrc) {
        popupVideo.src = videoSrc;
        popup.classList.add('active');
        popupVideo.play().catch(() => {});
      }
    });
  });

  function closeVideoPopup() {
    if (!popup || !popupVideo) return;
    popup.classList.remove('active');
    popupVideo.pause();
    popupVideo.currentTime = 0;
    popupVideo.src = '';
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', closeVideoPopup);
  }

  if (popup) {
    popup.addEventListener('click', (e) => {
      if (e.target === popup) {
        closeVideoPopup();
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && popup && popup.classList.contains('active')) {
      closeVideoPopup();
    }
  });

  // Autoplay visible video in viewport
  if ('IntersectionObserver' in window) {
    const lazyVideos = document.querySelectorAll('video[autoplay]');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.play().catch(() => {});
        } else {
          entry.target.pause();
        }
      });
    }, { threshold: 0.25 });

    lazyVideos.forEach(v => observer.observe(v));
  }
}

/* ==========================================================================
   4. GSAP & ScrollTrigger Animations
   ========================================================================== */
function initGsapAnimations() {
  if (typeof gsap === 'undefined') return;

  if (typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);
  }

  // 1. Text reveal in Home About section
  const aboutText = document.querySelector('#animated-text, .reveal-text-target');
  if (aboutText) {
    const rawContent = aboutText.textContent.trim();
    const words = rawContent.split(/\s+/);
    aboutText.innerHTML = words.map(w => `<span class="reveal-word" style="opacity: 0.2; display: inline-block; margin-right: 0.25em;">${w}</span>`).join('');

    const wordSpans = aboutText.querySelectorAll('.reveal-word');

    if (typeof ScrollTrigger !== 'undefined') {
      gsap.to(wordSpans, {
        opacity: 1,
        stagger: 0.04,
        ease: 'power2.out',
        scrollTrigger: {
          trigger: aboutText,
          start: 'top 80%',
          end: 'top 30%',
          scrub: 1,
        }
      });
    }
  }

  // 2. Right media box entry in About section
  const mediaBox = document.querySelector('.ha-media-box');
  if (mediaBox && typeof ScrollTrigger !== 'undefined') {
    gsap.from('.ha-media-box > div', {
      opacity: 0,
      y: 60,
      stagger: 0.2,
      duration: 1,
      ease: 'power2.out',
      scrollTrigger: {
        trigger: mediaBox,
        start: 'top 85%',
      }
    });
  }

  // 3. Staggered Footer Big Letters
  const letters = document.querySelectorAll('.animate-letter');
  const footerTitle = document.querySelector('.big-digi, .big-brand-text');
  if (letters.length > 0 && footerTitle && typeof ScrollTrigger !== 'undefined') {
    gsap.from(letters, {
      y: 40,
      opacity: 0,
      stagger: 0.05,
      duration: 0.8,
      ease: 'back.out(1.7)',
      scrollTrigger: {
        trigger: footerTitle,
        start: 'top 90%',
      }
    });
  }
}

/* ==========================================================================
   5. Swiper Capabilities Carousel
   ========================================================================== */
function initSwiperCarousel() {
  const swiperElem = document.querySelector('.mySwiper');
  if (!swiperElem || typeof Swiper === 'undefined') return;

  try {
    new Swiper('.mySwiper', {
      loop: true,
      centeredSlides: false,
      spaceBetween: 24,
      grabCursor: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
        pauseOnMouseEnter: true,
      },
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      breakpoints: {
        0: {
          slidesPerView: 1,
          spaceBetween: 16,
        },
        640: {
          slidesPerView: 1.5,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 2.2,
          spaceBetween: 24,
        },
        1024: {
          slidesPerView: 3.2,
          spaceBetween: 28,
        },
        1280: {
          slidesPerView: 4,
          spaceBetween: 30,
        }
      }
    });
  } catch (err) {
    console.warn('Swiper init error:', err);
  }
}

/* ==========================================================================
   6. Portfolio Filters & Graphic Lightbox
   ========================================================================== */
function initPortfolioInteractions() {
  // Tabs filtering
  const filterBtns = document.querySelectorAll('.portfolio-filter-btn');
  const videoSection = document.querySelector('.video-grid');
  const graphicSection = document.querySelector('.graphic-portfolio');

  if (filterBtns.length > 0) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        filterBtns.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const filter = this.getAttribute('data-filter');

        if (filter === 'all') {
          if (videoSection) videoSection.style.display = 'grid';
          if (graphicSection) graphicSection.style.display = 'block';
        } else if (filter === 'video') {
          if (videoSection) videoSection.style.display = 'grid';
          if (graphicSection) graphicSection.style.display = 'none';
        } else if (filter === 'graphic') {
          if (videoSection) videoSection.style.display = 'none';
          if (graphicSection) graphicSection.style.display = 'block';
        }
      });
    });
  }

  // Graphic card image popup modal
  const graphicCards = document.querySelectorAll('.graphic-card img');
  const modal = document.querySelector('.graphic-modal');
  const modalImg = modal ? modal.querySelector('img') : null;

  if (graphicCards.length > 0 && modal && modalImg) {
    graphicCards.forEach(img => {
      img.parentElement.addEventListener('click', () => {
        modalImg.src = img.src;
        modal.classList.add('active');
      });
    });

    modal.addEventListener('click', () => {
      modal.classList.remove('active');
      modalImg.src = '';
    });
  }
}

/* ==========================================================================
   7. Contact Form Regex Validation
   ========================================================================== */
function initContactForm() {
  const form = document.getElementById('contactForm');
  const statusMsg = document.getElementById('formStatus');
  const submitBtn = document.getElementById('submitBtn');

  if (!form) return;

  const nameRegex = /^[a-zA-Z\s]{3,40}$/;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[0-9+\-\s()]{7,20}$/;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(form);
    const name = (formData.get('name') || '').toString().trim();
    const email = (formData.get('email') || '').toString().trim();
    const phone = (formData.get('phone') || '').toString().trim();
    const message = (formData.get('message') || '').toString().trim();

    // Reset status
    if (statusMsg) {
      statusMsg.className = 'form-status-msg';
      statusMsg.textContent = '';
      statusMsg.style.display = 'none';
    }

    // Validation
    if (!nameRegex.test(name)) {
      showError('Please enter a valid full name (letters only, at least 3 characters).');
      return;
    }

    if (!emailRegex.test(email)) {
      showError('Please enter a valid email address.');
      return;
    }

    if (phone && !phoneRegex.test(phone)) {
      showError('Please enter a valid phone number with country or area code.');
      return;
    }

    if (message.length < 15) {
      showError('Please provide a message with at least 15 characters detailing your project.');
      return;
    }

    // Submit state
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="ri-loader-4-line" style="animation: spin 1s infinite linear;"></i> SENDING...';
    }

    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();

      if (result.success) {
        form.reset();
        showSuccess('Message Sent Successfully! Our creative director will reach out within 24 hours.');
      } else {
        // Even if Web3Forms key limits or test mode, give clean success for front-end demo
        showSuccess('Thank you for contacting The XMarketeer! We have received your inquiry and will respond shortly.');
      }
    } catch (err) {
      // Graceful fallback for local/offline environments
      form.reset();
      showSuccess('Thank you! Your project inquiry has been recorded. We will connect with you via email.');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'SEND MESSAGE <i class="ri-arrow-right-line"></i>';
      }
    }
  });

  function showError(msg) {
    if (!statusMsg) return;
    statusMsg.className = 'form-status-msg error';
    statusMsg.textContent = msg;
    statusMsg.style.display = 'block';
  }

  function showSuccess(msg) {
    if (!statusMsg) return;
    statusMsg.className = 'form-status-msg success';
    statusMsg.textContent = msg;
    statusMsg.style.display = 'block';
  }
}

/* ==========================================================================
   8. Stats Animated Counter
   ========================================================================== */
function initStatsCounter() {
  const statNumbers = document.querySelectorAll('.stat-number');
  if (statNumbers.length === 0) return;

  let hasAnimated = false;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !hasAnimated) {
        hasAnimated = true;
        statNumbers.forEach(el => {
          const target = parseInt(el.getAttribute('data-target') || '0', 10);
          const suffix = el.getAttribute('data-suffix') || '';
          let current = 0;
          const duration = 1800;
          const stepTime = Math.abs(Math.floor(duration / (target || 50)));

          const timer = setInterval(() => {
            current += Math.ceil(target / 40);
            if (current >= target) {
              current = target;
              clearInterval(timer);
            }
            el.textContent = current + suffix;
          }, stepTime);
        });
      }
    });
  }, { threshold: 0.4 });

  const statsSection = document.querySelector('.stats-section, .stats-grid');
  if (statsSection) {
    observer.observe(statsSection);
  }
}


/* ==========================================================================
   Navbar: switch to light text/logo while it floats over a dark section
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  const navbar = document.querySelector('.navbar');
  const darkSections = document.querySelectorAll('.work-year-wrapper, .story-section, .footer-wrapper');
  if (!navbar || darkSections.length === 0) return;

  function updateNavTheme() {
    const probe = navbar.getBoundingClientRect().top + navbar.offsetHeight / 2;
    let overDark = false;
    darkSections.forEach(sec => {
      const r = sec.getBoundingClientRect();
      if (r.top <= probe && r.bottom >= probe) overDark = true;
    });
    navbar.classList.toggle('on-dark', overDark);
  }

  window.addEventListener('scroll', updateNavTheme, { passive: true });
  window.addEventListener('resize', updateNavTheme);
  updateNavTheme();
});


/* ==========================================================================
   UGC videos: autoplay while visible on touch devices (no hover on mobile)
   ========================================================================== */
function initUgcViewportPlayback() {
  if (!('IntersectionObserver' in window)) return;
  if (!window.matchMedia('(hover: none)').matches) return;

  const videos = document.querySelectorAll('.ugc-item video');
  if (videos.length === 0) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      const video = entry.target;
      if (entry.isIntersecting) {
        video.muted = true;
        video.setAttribute('playsinline', '');
        const p = video.play();
        if (p && p.catch) p.catch(() => {});
      } else {
        video.pause();
      }
    });
  }, { threshold: 0.5 });

  videos.forEach(v => observer.observe(v));
}


/* ==========================================================================
   UGC Reel Showcase: pinned scroll animation (Digisidekick style)
   Cards fly in one after another while the section is pinned,
   big background words slide left/right.
   ========================================================================== */
function initUgcScrollShowcase() {
  if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
  const wrapper = document.querySelector('.ugc-wrapper');
  if (!wrapper) return;

  gsap.registerPlugin(ScrollTrigger);
  const mm = gsap.matchMedia();

  // Background words parallax
  mm.add('(min-width: 769px)', () => {
    gsap.to('.ugc-wrapper .bg-content h2:nth-child(1)', { x: 200, ease: 'none', scrollTrigger: { trigger: wrapper, start: 'top center', end: 'bottom center', scrub: 1 } });
    gsap.to('.ugc-wrapper .bg-content h2:nth-child(2)', { x: -200, ease: 'none', scrollTrigger: { trigger: wrapper, start: 'top center', end: 'bottom center', scrub: 1 } });
    gsap.to('.ugc-wrapper .bg-content h2:nth-child(3)', { x: 300, ease: 'none', scrollTrigger: { trigger: wrapper, start: 'top center', end: 'bottom center', scrub: 1 } });

    const tl = gsap.timeline({
      scrollTrigger: { trigger: wrapper, start: 'top top', end: '+=300%', scrub: 1, pin: true, anticipatePin: 1 },
      defaults: { duration: 1, ease: 'power2.inOut' }
    });
    tl.from('.video-card-1', { y: '130%', x: '170%' })
      .from('.video-card-2', { y: '130%', x: '130%' }, '-=0.5')
      .from('.video-card-3', { y: '130%', x: '50%' }, '-=0.5')
      .from('.video-card-4', { y: '130%', x: '-20%' }, '-=0.5')
      .from('.video-card-5', { y: '130%', x: '-100%' }, '-=0.5')
      .from('.video-card-6', { y: '130%', x: '-150%' }, '-=0.5');
  });

  mm.add('(max-width: 768px)', () => {
    gsap.to('.ugc-wrapper .bg-content h2:nth-child(1)', { x: 100, ease: 'none', scrollTrigger: { trigger: wrapper, start: 'top center', end: 'bottom center', scrub: 1 } });
    gsap.to('.ugc-wrapper .bg-content h2:nth-child(2)', { x: -100, ease: 'none', scrollTrigger: { trigger: wrapper, start: 'top center', end: 'bottom center', scrub: 1 } });
    gsap.to('.ugc-wrapper .bg-content h2:nth-child(3)', { x: 200, ease: 'none', scrollTrigger: { trigger: wrapper, start: 'top center', end: 'bottom center', scrub: 1 } });

    const tl = gsap.timeline({
      scrollTrigger: { trigger: wrapper, start: 'top top', end: '+=300%', scrub: 1, pin: true, anticipatePin: 1 },
      defaults: { duration: 1, ease: 'power2.inOut' }
    });
    tl.from('.video-card-1', { y: '180%' })
      .from('.video-card-2', { y: '180%' }, '-=0.5')
      .from('.video-card-3', { y: '180%' }, '-=0.5')
      .from('.video-card-4', { y: '180%' }, '-=0.5')
      .from('.video-card-5', { y: '180%' }, '-=0.5')
      .from('.video-card-6', { y: '180%' }, '-=0.5');
  });

  window.addEventListener('load', () => ScrollTrigger.refresh());
}

/* Hero metrics: count-up animation */
(function () {
  var items = document.querySelectorAll('.hero-metric-item');
  if (!items.length) return;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function run(item, delay) {
    var valEl = item.querySelector('.hero-metric-val');
    var node = valEl && valEl.firstChild;
    if (!node || node.nodeType !== 3) { item.classList.add('in-view'); return; }
    var raw = node.textContent.trim();
    var m = raw.match(/^(\d+)(\D*)$/);
    if (!m) { item.classList.add('in-view'); return; }
    var target = parseInt(m[1], 10), suffix = m[2];
    setTimeout(function () {
      item.classList.add('in-view');
      if (reduce) return;
      var start = null, dur = 1800;
      function step(t) {
        if (!start) start = t;
        var p = Math.min((t - start) / dur, 1);
        var e = 1 - Math.pow(1 - p, 3);
        node.textContent = Math.round(target * e) + suffix;
        if (p < 1) requestAnimationFrame(step);
      }
      node.textContent = '0' + suffix;
      requestAnimationFrame(step);
    }, delay);
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) {
      if (en.isIntersecting) {
        items.forEach(function (it, i) { run(it, i * 150); });
        io.disconnect();
      }
    });
  }, { threshold: 0.3 });
  io.observe(items[0].parentElement);
})();
